package com.test.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.test.baseclass.BaseClass;
import com.test.context.Context;

public class ESSPage extends BaseClass {

	@FindBy(xpath = "//input[@data-default_value='Enter Search Term']")
	public WebElement searchBox;

	@FindBy(xpath = "//div[.='Products']")
	public WebElement productsTab;

	@FindBy(xpath = "//div[contains(@class,'tech_service')]//a")
	public List<WebElement> techInfoLinks;

	@FindBy(xpath = "//div[contains(@class,'product_msds')]//a")
	public List<WebElement> SDSLinks;

	@FindBy(xpath = "//div[contains(@class,'pickcodes-data-grid-wrap')]//div[contains(@class,'grid-cell')]")
	public List<WebElement> OrderingInfo;

	@FindBy(xpath = "//div[contains(@id,'pt3')]//div[contains(@class,'col-2 grid-cell')]")
	public List<WebElement> SpecificationInfo;

	@FindBy(xpath = "//div[@class='product_long_desc']//p")
	public WebElement productDesc;

	@FindBy(xpath = "//div[.='Ordering']")
	public WebElement orderingTab;

	@FindBy(xpath = "//div[.='Specifications']")
	public WebElement specificationTab;

	@FindBy(xpath = "//div[contains(@class,'customer-materials')]//a")
	public List<WebElement> customer_Materials_links;

	@FindBy(xpath = "//div[contains(@class,'internal-materials')]//a")
	public List<WebElement> internal_Materials_links;

	@FindBy(xpath = "//a[.='Change']")
	public WebElement changeCountryLink;

	@FindBy(xpath = "//input[contains(@id,'country]us')]")
	public WebElement USCountryRadioButton;

	@FindBy(xpath = "//input[contains(@id,'country]ca')]")
	public WebElement canadaCountryRadioButton;

	@FindBy(id = "save_user_setting")
	public WebElement saveUserSettings;

	public ESSPage() {
		PageFactory.initElements(browserFactory.getDriver(), this);
	}

	public ESSPage enterTextInSearchBox(String text) {
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(searchBox)).clear();
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(searchBox)).sendKeys(text);
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(searchBox)).sendKeys(Keys.ENTER);
		return this;
	}

	public ESSPage clickOnProductTab() {
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(productsTab)).click();
		return this;
	}

	public ESSPage setCountry() {
		if (Context.tempValues.get("Country").toLowerCase().contains("usa")) {
			browserFactory.getWait().until(ExpectedConditions.visibilityOf(changeCountryLink)).click();
			browserFactory.getWait().until(ExpectedConditions.visibilityOf(USCountryRadioButton)).click();
		} else {
			browserFactory.getWait().until(ExpectedConditions.visibilityOf(changeCountryLink)).click();
			browserFactory.getWait().until(ExpectedConditions.visibilityOf(canadaCountryRadioButton)).click();
		}
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(saveUserSettings)).click();
		return this;
	}

	public ESSPage clickOnProducts(String productName) {
		browserFactory.getWait()
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[.='" + productName + "']"))).click();
		return this;
	}

	public List<String> getTechnicalInfoLinks() {
		List<String> TechnicalInfoLink = new ArrayList<String>();
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(techInfoLinks)).stream()
					.forEach(e -> TechnicalInfoLink.add(e.getText()));
		} catch (Exception e) {
		}
		return TechnicalInfoLink;
	}

	public List<String> getOrderingInfo() {
		List<String> Ordering = new ArrayList<String>();
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOf(orderingTab)).click();
			browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(OrderingInfo)).stream()
					.filter(e -> !e.getText().equals("")).forEach(e -> Ordering.add(e.getText()));
		} catch (Exception e) {

		}
		return Ordering;
	}

	public List<String> getSpecificationInfo() {
		List<String> specification = new ArrayList<String>();
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOf(specificationTab)).click();
			browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(SpecificationInfo)).stream()
					.filter(e -> !e.getText().equals("")).forEach(e -> specification.add(e.getText()));
		} catch (Exception e) {

		}
		return specification;
	}

	public String productDescription() {
		try {
			return browserFactory.getWait().until(ExpectedConditions.visibilityOf(productDesc)).getText().substring(0,
					21);
		} catch (Exception e) {
			return "";
		}
	}

	public List<String> getSDSLinks() {
		List<String> SDSLinkNames = new ArrayList<String>();
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(SDSLinks)).stream()
					.forEach(e -> SDSLinkNames.add(StringUtils.substringAfterLast(e.getText(), " - ") + " - "
							+ StringUtils.substringBeforeLast(e.getText(), " - ")));
		} catch (Exception e) {

		}
		return SDSLinkNames;
	}

	public Map<String, Boolean> getFAQLinks() {
		Map<String, Boolean> FAQLinks = new LinkedHashMap<String, Boolean>();
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(customer_Materials_links))
					.stream().filter(e -> e.getText().trim().toLowerCase().contains("faq"))
					.forEach(e -> FAQLinks.put(e.getText().trim(), false));
		} catch (Exception e) {
		}
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(internal_Materials_links))
					.stream().filter(e -> e.getText().trim().toLowerCase().contains("faq"))
					.forEach(e -> FAQLinks.put(e.getText().trim(), true));
		} catch (Exception e) {
		}
		return FAQLinks;
	}

	public Map<String, Boolean> getVideoLinks() {
		Map<String, Boolean> Videos = new LinkedHashMap<String, Boolean>();
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(customer_Materials_links))
					.stream().filter(e -> e.getText().trim().toLowerCase().contains("Video".toLowerCase()))
					.forEach(e -> Videos.put(e.getText().trim(), false));
		} catch (Exception e) {

		}
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(internal_Materials_links))
					.stream().filter(e -> e.getText().trim().toLowerCase().contains("Video".toLowerCase()))
					.forEach(e -> Videos.put(e.getText().trim(), true));
		} catch (Exception e) {

		}
		return Videos;
	}
}
