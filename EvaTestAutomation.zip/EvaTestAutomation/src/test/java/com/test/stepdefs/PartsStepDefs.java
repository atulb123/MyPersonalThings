package com.test.stepdefs;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.test.baseclass.BaseClass;
import com.test.missions.PartsAPIMission;
import com.test.missions.PartsAPIParallelMissions;
import com.test.missions.PartsMissions;
import com.test.pages.CommonPage;
import com.test.utility.GetPropertiesData;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PartsStepDefs extends BaseClass {
	private CommonPage commonPage = new CommonPage();
	private PartsMissions partsMissions = new PartsMissions();
	private PartsAPIMission partsAPIMission = new PartsAPIMission();
	private PartsAPIParallelMissions partsAPIParallelMissions = new PartsAPIParallelMissions();

	@Given("I should see list of parts related to SCLS displayed")
	public void i_should_see_list_of_parts_related_to_SCLS_displayed() {
		Assert.assertTrue(browserFactory.getWait()
				.until(ExpectedConditions
						.numberOfElementsToBeMoreThan(By.xpath("//div[@aria-label='Product Details card']"), 0))
				.size() > 0, "Parts list not displayed");
	}

	@Then("I should see specific part information along with {string} and {string} buttons")
	public void i_should_see_specific_part_information_along_with_and_buttons(String viewPart, String addToCart) {
		Assert.assertTrue(browserFactory.getWait().until(ExpectedConditions.attributeContains(
				By.xpath("(//button[contains(@aria-label,'" + viewPart + "')])[last()]"), "aria-label", viewPart)),
				"viewPart link not displayed");
		Assert.assertTrue(browserFactory.getWait().until(ExpectedConditions.attributeContains(
				By.xpath("(//button[contains(@aria-label,'" + addToCart + "')])[last()]"), "aria-label", addToCart)),
				"addToCart link not displayed");
	}

	@Given("I choose {string} as option")
	public void i_choose_as_option(String option) {
		commonPage.clickOption(option);
	}

	@Then("I should see a message stating {string}")
	public void i_should_see_a_message_stating(String text) {
		Assert.assertTrue(commonPage.verifyMessageFromChatBot(text), "Corresponding message is not displayed");
	}

	@Given("I Enter {string} as option")
	public void i_Enter_as_option(String option) {
		commonPage.enterOption(option);
	}

	@Then("I should see parts list containing {string} displayed")
	public void i_should_see_parts_list_containing_displayed(String partName) {
		Assert.assertTrue(partsMissions.verifyPartsList(partName), "Part List Not Displayed");
	}

	@Then("Verify Part search is returning the right part info")
	public void verify_Part_search_is_returning_the_right_part_info() throws Throwable {
		partsMissions.searchPart();
	}

	@Then("Verify Part search is returning the right part info when searched directly")
	public void verify_Part_search_is_returning_the_right_part_info_when_searched_directly() throws Throwable {
		partsMissions.PartsLookup();
	}

	@Then("I should see parts details when I enter {string}")
	public void i_should_see_parts_details_when_I_enter(String partName) {
		commonPage.enterTxt(partName);
		Assert.assertTrue(browserFactory.getWait()
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
						By.xpath("(//p[.='Top Results'])[last()]//..//..//..//..//..//p")))
				.stream()
				.filter(e -> e.getText().toLowerCase().trim()
						.equals(StringUtils.substringAfter(partName, "Parts Lookup ").toLowerCase().trim()))
				.findFirst().get().isDisplayed(), "Parts Details not displayed");
	}

	@Given("Get All parts data from ecolab equipment catalog website")
	public void get_All_parts_data_from_ecolab_equipment_catalog_website() throws Throwable {
		browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("eec"));
		partsMissions.getPartsData();
	}

	@Given("Get All assembly data from ecolab equipment catalog website")
	public void get_All_assembly_data_from_ecolab_equipment_catalog_website() throws Throwable {
		browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("eec"));
		partsMissions.getAssemblyData();
	}

	@Given("Verify Parts details through API request in {string} env")
	public void verify_Parts_details_through_API_request_in_env(String env) throws Throwable {
		partsAPIMission.verifyPartsDetails(env);
	}

	@Given("Verify Parts details through API request in {string} env by giving only parent name")
	public void verify_Parts_details_through_API_request_in_env_by_giving_only_parent_name(String env) throws Throwable {
		partsAPIMission.verifyPartsDetailsByParentName(env);
	}

	@Given("Verify parts Uttrances through API request in {string} env with PARALLEL Executions")
	public void verify_parts_Uttrances_through_API_request_in_env_with_PARALLEL_Executions(String env)
			throws Throwable {
		partsAPIParallelMissions.validatePartsUttrancesParallelyThroughAPI(env);
	}

	@Given("Verify bulk dispenser parts Uttrances through API request in {string} env with PARALLEL Executions")
	public void verify_bulk_dispenser_parts_Uttrances_through_API_request_in_env_with_PARALLEL_Executions(String env) throws Throwable {
		partsAPIParallelMissions.validateBuldDispenserPartsUttrancesParallelyThroughAPI(env);
	}

	@Given("Verify parts Uttrances through API request in {string} env when searched along with model name  with PARALLEL Executions")
	public void verify_parts_Uttrances_through_API_request_in_env_when_searched_along_with_model_name_with_PARALLEL_Executions(
			String env) throws Throwable {
		partsAPIParallelMissions.validatePartsUttrancesAlongWithModelNameParallelyThroughAPI(env);
	}

	@Given("I try to give invalid parts search then I should see {string} message displayed")
	public void i_try_to_give_invalid_parts_search_then_I_should_see_message_displayed(String message,
			DataTable dataTable) {
		for (int i = 0; i < dataTable.asList().size(); i++) {
			commonPage.enterTxt(dataTable.asList().get(i));
			browserFactory.getWait().until(
					ExpectedConditions.numberOfElementsToBe(By.xpath("//p[contains(.,'" + message + "')]"), i + 1));
		}
	}

	@Given("I Enter input as below and select random part from the list")
	public void i_Enter_input_as_below_and_select_random_part_from_the_list(DataTable dataTable) {
		Assert.assertTrue(partsMissions.selectRandomPartFromList(dataTable), "Not able to remove part");
	}

	@When("I refresh the page and enter {string}")
	public void i_refresh_the_page_and_enter(String input) {
		browserFactory.getDriver().navigate().refresh();
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(commonPage.welcomeMessageTextBlock));
		commonPage.enterTxt(input);
	}

	@Then("I add same part twice to the list")
	public void i_add_same_part_twice_to_the_list() {
		partsMissions.clickSamePartTwice();
	}

	@Then("I should see same part should be added only once")
	public void i_should_see_same_part_should_be_added_only_once() {
		Assert.assertTrue(commonPage.viewMyListAdaptiveCards.size() == 1, "Duplicate Parts are displayed");
	}

	@Given("Verify Parts Assemblies through API request in {string} env when partial or invalid assembly name is given")
	public void verify_Parts_Assemblies_through_API_request_in_env_when_partial_or_invalid_assembly_name_is_given(
			String env) throws Throwable {
		partsAPIMission.verifyAssemblyDetailsWhenPartialNameIsGiven(env);
	}

	@Given("Verify Parts Details through API request in {string} env when partial part name is given")
	public void verify_Parts_Details_through_API_request_in_env_when_partial_part_name_is_given(String env)
			throws Throwable {
		partsAPIMission.verifyPartsDetailsWhenPartialNameIsGiven(env);
	}

	@Given("Verify Parts Details through API request in {string} env when part name is given along with model name")
	public void verify_Parts_Details_through_API_request_in_env_when_part_name_is_given_along_with_model_name(
			String env) throws Throwable {
		partsAPIMission.verifyPartsDetailsWhenSearchedWithModelName(env);
	}

	@Given("Verify annotated images for Uttrances through API request in {string} env")
	public void verify_annotated_images_for_Uttrances_through_API_request_in_env(String env) throws Throwable {
		partsAPIParallelMissions.validatePartsAnnotatedImagesParallelyThroughAPI(env);
	}
}
