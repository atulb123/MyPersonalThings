package com.test.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Reporter;

import com.test.baseclass.BaseClass;

import io.appium.java_client.AppiumDriver;

public class CommonPage extends BaseClass {

	@FindBy(xpath = "//input[@data-id='webchat-sendbox-input']")
	public WebElement inputTextBox;

	@FindBy(xpath = "//button[@type='button']")
	public WebElement menuButton;

	@FindBy(xpath = "//button[.='View Details']")
	public WebElement viewDetailsButton;

	@FindBy(xpath = "(//*[.='Here are your ticket'])[last()]")
	public WebElement ticketTextArea;

	@FindBy(xpath = "//p[contains(.,'help you')]")
	public WebElement welcomeMessageTextBlock;

	@FindBy(xpath = "//p[contains(.,'Doug Baker')]")
	public WebElement ceoDescriptionTextBlock;

	@FindBy(xpath = "((//p[contains(.,'Here are your open tickets')])[last()]//..//..//..//..//..//p)[2]")
	public WebElement firstTicketTextBlock;

	@FindBy(xpath = "((//p[contains(.,'Here are your open tickets')])[last()]//..//..//..//..//..//button)[2]")
	private WebElement firstTicketResolveTicketButton;

	@FindBy(xpath = "((//p[contains(.,'Here are your pending')])[last()]//..//..//..//..//..//p)[2]")
	public WebElement firstApprovalTicketTextBlock;

	@FindBy(xpath = "//div[@class='panel-body']//div[contains(.,'Pre-ECL-072 - Standard Network Changes')]")
	public WebElement ticketDescription;

	@FindBy(xpath = "((//p[contains(.,'recently resolved tickets')])[last()]//..//..//..//..//..//p)[2]")
	public WebElement firstRecentResolveTicketTextBlock;

	@FindBy(xpath = "(//div[contains(@class,'webchat__carousel_indented_content')])[last()]//button[.='Add to My List']")
	public List<WebElement> addToMyListButtons;

	@FindBy(xpath = "(//div[contains(@class,'webchat__carousel_indented_content')])[last()]//div[contains(@class,'adaptiveCard')]")
	public List<WebElement> partAdaptiveCards;

	@FindBy(xpath = "((//p[contains(.,'Here are the part')])[last()]//..//..//..//..//..//p)")
	public List<WebElement> viewMyListAdaptiveCardsTextLabel;

	@FindBy(xpath = "((//p[contains(.,'Here are the part')])[last()]//..//..//..//..//..//div[contains(@class,'adaptive-card')])")
	public List<WebElement> viewMyListAdaptiveCards;

	@FindBy(id = "openhamburgermenu")
	public WebElement hamBurgerIcon;

	public CommonPage() {
		PageFactory.initElements(browserFactory.getDriver(), this);
	}

	public CommonPage clickMenuOption(String text) {
		try {
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
					browserFactory.getDriver()
							.findElement(By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]")));
			browserFactory.getWait().until(ExpectedConditions.attributeContains(
					By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]"), "aria-label", text));
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();", browserFactory
					.getDriver().findElement(By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]")));
			browserFactory.getWait()
					.until(ExpectedConditions.attributeContains(By.xpath(
							"(//div[@class='webchat__row message']//*[contains(@aria-label,'" + text + "')])[last()]"),
							"aria-label", text));
		} catch (Exception e) {
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
					browserFactory.getDriver()
							.findElement(By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]")));
			browserFactory.getWait().until(ExpectedConditions.attributeContains(
					By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]"), "aria-label", text));
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();", browserFactory
					.getDriver().findElement(By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]")));
			browserFactory.getWait()
					.until(ExpectedConditions.attributeContains(By.xpath(
							"(//div[@class='webchat__row message']//*[contains(@aria-label,'" + text + "')])[last()]"),
							"aria-label", text));
		}
		return this;
	}

	public CommonPage enterMenuOption(String text) {
		try {
			browserFactory.getWait().until(ExpectedConditions.attributeContains(
					By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]"), "aria-label", text));
			inputTextBox.sendKeys(text);
			inputTextBox.sendKeys(Keys.ENTER);
			browserFactory.getWait()
					.until(ExpectedConditions.attributeContains(By.xpath(
							"(//div[@class='webchat__row message']//*[contains(@aria-label,'" + text + "')])[last()]"),
							"aria-label", text));
		} catch (Exception e) {
			browserFactory.getWait().until(ExpectedConditions.attributeContains(
					By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]"), "aria-label", text));
			inputTextBox.sendKeys(text);
			inputTextBox.sendKeys(Keys.ENTER);
			browserFactory.getWait()
					.until(ExpectedConditions.attributeContains(By.xpath(
							"(//div[@class='webchat__row message']//*[contains(@aria-label,'" + text + "')])[last()]"),
							"aria-label", text));
		}
		return this;
	}

	public CommonPage clickOption(String option) {
		try {
			browserFactory.getWait().until(ExpectedConditions
					.textToBePresentInElementLocated(By.xpath("//button//nobr[.='" + option + "']"), option));
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();",
					browserFactory.getDriver().findElement(By.xpath("//button//nobr[.='" + option + "']")));
		} catch (Exception e) {
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();",
					browserFactory.getDriver().findElement(By.xpath("//button//nobr[.='" + option + "']")));
		}
		return this;
	}

	public CommonPage enterText(String text) {
		inputTextBox.sendKeys(text);
		inputTextBox.sendKeys(Keys.ENTER);
		browserFactory.getWait()
				.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("(//p)[last()]"), text));
		return this;
	}

	public boolean verifyMessageFromChatBot(String text) {
		return browserFactory.getWait().until(ExpectedConditions.textToBePresentInElementLocated(
				By.xpath("((//div[@class='webchat__row message'])[last()])//p"), text));
	}

	public CommonPage enterOption(String option) {
		try {
			browserFactory.getWait().until(ExpectedConditions
					.textToBePresentInElementLocated(By.xpath("//button//nobr[.='" + option + "']"), option));
			inputTextBox.sendKeys(option);
			inputTextBox.sendKeys(Keys.ENTER);
			browserFactory.getWait().until(ExpectedConditions.attributeContains(By
					.xpath("(//div[@class='webchat__row message']//*[contains(@aria-label,'" + option + "')])[last()]"),
					"aria-label", option));

		} catch (Exception e) {
			browserFactory.getWait().until(ExpectedConditions
					.textToBePresentInElementLocated(By.xpath("//button//nobr[.='" + option + "']"), option));
			inputTextBox.sendKeys(option);
			inputTextBox.sendKeys(Keys.ENTER);
			browserFactory.getWait().until(ExpectedConditions.attributeContains(By
					.xpath("(//div[@class='webchat__row message']//*[contains(@aria-label,'" + option + "')])[last()]"),
					"aria-label", option));
		}
		return this;
	}

	public CommonPage clickMenuButton(String buttonText, String menuText) {
		try {
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
					browserFactory.getDriver()
							.findElement(By.xpath("(//*[contains(@class,'adaptiveCard')]//p[contains(.,'" + menuText
									+ "')]/../../../../..//button[@aria-label='" + buttonText + "'])[last()]")));
			browserFactory.getWait()
					.until(ExpectedConditions.attributeContains(
							By.xpath("(//*[contains(@class,'adaptiveCard')]//p[contains(.,'" + menuText
									+ "')]/../../../../..//button[@aria-label='" + buttonText + "'])[last()]"),
							"aria-label", buttonText));
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();",
					browserFactory.getDriver()
							.findElement(By.xpath("(//*[contains(@class,'adaptiveCard')]//p[contains(.,'" + menuText
									+ "')]/../../../../..//button[@aria-label='" + buttonText + "'])[last()]")));
		} catch (Exception e) {
			browserFactory.getWait()
					.until(ExpectedConditions.attributeContains(
							By.xpath("(//*[contains(@class,'adaptiveCard')]//p[contains(.,'" + menuText
									+ "')]/../../../../..//button[@aria-label='" + buttonText + "'])[last()]"),
							"aria-label", buttonText));
			((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();",
					browserFactory.getDriver()
							.findElement(By.xpath("(//*[contains(@class,'adaptiveCard')]//p[contains(.,'" + menuText
									+ "')]/../../../../..//button[@aria-label='" + buttonText + "'])[last()]")));
		}
		return this;
	}

	public boolean verifyTextBlockIsDisplayed(String text) {
		return browserFactory.getWait().until(ExpectedConditions
				.textToBePresentInElementLocated(By.xpath("(//p[contains(.,'" + text + "')])[last()]"), text));
	}

	public CommonPage enterTxt(String text) {
		inputTextBox.sendKeys(text);
		inputTextBox.sendKeys(Keys.ENTER);
		return this;
	}

	public CommonPage clickButton(String text) {
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
				browserFactory.getDriver()
						.findElement(By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]")));
		browserFactory.getWait().until(ExpectedConditions.attributeContains(
				By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]"), "aria-label", text));
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();", browserFactory
				.getDriver().findElement(By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]")));
		return this;
	}

	public CommonPage selectFirstITTicket(String text) {
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
				browserFactory.getDriver().findElement(By.xpath("(//button[contains(@aria-label,'" + text + "')])")));
		browserFactory.getWait().until(ExpectedConditions
				.attributeContains(By.xpath("(//button[contains(@aria-label,'" + text + "')])"), "aria-label", text));
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();",
				browserFactory.getDriver().findElement(By.xpath("(//button[contains(@aria-label,'" + text + "')])")));
		return this;
	}

	public CommonPage clickResolveTicket() {
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
				firstTicketResolveTicketButton);
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();",
				firstTicketResolveTicketButton);
		return this;
	}

	public boolean verifylastMessageFromBot(String message) {
		return browserFactory.getWait()
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("(//p[contains(.,'" + message + "')])[last()]")))
				.isDisplayed();
	}

	public CommonPage clickByJavaScript(WebElement element) {
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();", element);
		return this;
	}

	public void WaitForAjax() throws InterruptedException {
		int i = 0;
		while (i < 10) {
			Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor) browserFactory.getDriver())
					.executeScript("return jQuery.active == 0");
			if (ajaxIsComplete) {
				break;
			}
			Thread.sleep(100);
			i++;
		}
	}

	public CommonPage clickHamBurgerIconAndSelectMenu(String text) {
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(hamBurgerIcon)).click();
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();",
				browserFactory.getDriver().findElement(By.xpath("//li[.='" + text + "']")));
		return this;
	}

	public boolean verifyElementDisplayed(String locator) {
		return browserFactory.getWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)))
				.isDisplayed();
	}
}
