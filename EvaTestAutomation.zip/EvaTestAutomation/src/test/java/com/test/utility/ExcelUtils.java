package com.test.utility;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {

	private static String filePath;

	private static XSSFSheet ExcelWSheet;

	private static XSSFWorkbook ExcelWBook;

	private static XSSFCell Cell;

	private static XSSFRow Row;

	private static FileInputStream ExcelFile;
	
	private static FileOutputStream fileOut;

	public static void setExcelFile(String FilePath) throws Exception {
		try {
			filePath = FilePath;
			ExcelFile = new FileInputStream(FilePath);
			ExcelWBook = new XSSFWorkbook(ExcelFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void closeExcelFile(String FilePath) throws Exception {
		fileOut = new FileOutputStream(filePath);
		ExcelWBook.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	public static int getLastRownNo(String SheetName) {
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		return ExcelWSheet.getLastRowNum();
	}

	public static int getLastColumnNo(String SheetName, int row) {
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		return ExcelWSheet.getRow(row).getLastCellNum();
	}

	public static String getCellData(String SheetName, int RowNum, int ColNum) throws Exception {

		try {

			// Access the required test data sheet

			ExcelWSheet = ExcelWBook.getSheet(SheetName);

			String CellData = ExcelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue().toString();

			return CellData;
		} catch (Exception e) {
			// System.out.println("Running catch block");
//	DataFormatter dataFormatter = new DataFormatter();
//	 String CellData = dataFormatter.formatCellValue(ExcelWSheet.getRow(RowNum).getCell(ColNum));
			try {
				if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == Cell.CELL_TYPE_STRING) {
					return ExcelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();
				} else if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == Cell.CELL_TYPE_NUMERIC) {
					int value = (int) ExcelWSheet.getRow(RowNum).getCell(ColNum).getNumericCellValue();
					return value + "";
				} else if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == Cell.CELL_TYPE_BOOLEAN) {
					return ExcelWSheet.getRow(RowNum).getCell(ColNum).getBooleanCellValue() + "";
				} else if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == Cell.CELL_TYPE_BLANK) {
					return ExcelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();
				} else if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == Cell.CELL_TYPE_ERROR) {
					return ExcelWSheet.getRow(RowNum).getCell(ColNum).getErrorCellValue() + "";
				} else {
					return "";
				}
			} catch (Exception e2) {
				return "";
			}
		}

	}

	public static void setCellData(String SheetName, String Result, int RowNum, int ColNum) throws Exception {

		try {
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			Row = ExcelWSheet.getRow(RowNum);
			if (Row == null)
				Row = ExcelWSheet.createRow(RowNum);
			Cell = Row.getCell(ColNum);
			if (Cell == null)
				Cell = Row.createCell(ColNum);
			Cell.setCellValue(Result);
			XSSFCellStyle style = ExcelWBook.createCellStyle();
			XSSFFont font = ExcelWBook.createFont();
			font.setBold(true);
			style.setFont(font);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			Cell.setCellStyle(style);
		} catch (
		Exception e) {
			e.printStackTrace();
			System.out.println("running set cell data catch block");
		}
	}

	public static void setCellData(String SheetName, String Result, int RowNum, int ColNum, short color)
			throws Exception {

		try {
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			Row = ExcelWSheet.getRow(RowNum);
			if (Row == null)
				Row = ExcelWSheet.createRow(RowNum);
			Cell = Row.getCell(ColNum);
			if (Cell == null)
				Cell = Row.createCell(ColNum);
			Cell.setCellValue(Result);
			XSSFCellStyle style = ExcelWBook.createCellStyle();
			XSSFFont font = ExcelWBook.createFont();
			font.setBold(true);
			font.setColor(color);
			style.setFont(font);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			Cell.setCellStyle(style);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("running set cell data catch block");
		}
	}
}