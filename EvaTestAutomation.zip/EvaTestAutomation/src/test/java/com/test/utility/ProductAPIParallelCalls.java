package com.test.utility;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.test.baseclass.BaseClass;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import com.test.context.Context;

public class ProductAPIParallelCalls {
	public Map<String, String> apiValues = new HashMap<String, String>();
	public final String OAuth = Context.tempValues.get("OAuth");

	public void directLineTokenGenerator(String env) {
		Response response = given().body("{\"userID\":\"d0bcf8ef-07d5-49bf-ba66-e3dc3a3c747a\"}")
				.contentType(ContentType.TEXT).when().post("https://" + env + ".eva.ecolab.com/api/directline/token")
				.then().extract().response();
		apiValues.put("DLToken", response.jsonPath().get("token.token").toString());
		apiValues.put("userID", response.jsonPath().get("userID").toString());
	}

	public void conversationTokenGenerator() {
		Response response = given().header("Authorization", "Bearer " + apiValues.get("DLToken"))
				.header("Accept", "application/json").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))").when()
				.post("https://directline.botframework.com/v3/directline/conversations").then().extract().response();
		apiValues.put("conversationId", response.jsonPath().get("conversationId").toString());
		apiValues.put("conversationToken", response.jsonPath().get("token").toString());
	}

	public void activityEvent() {
		given().header("Authorization", "Bearer " + apiValues.get("conversationToken")).header("Accept", "*/*")
				.header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json")
				.body("{\"name\":\"oauth/signin\",\"type\":\"event\",\"channelData\":{\"oauthAccessToken\":\"" + OAuth
						+ "\",\"oauthProvider\":\"microsoft\"},\"channelId\":\"webchat\",\"from\":{\"id\":\""
						+ apiValues.get("userID")
						+ "\",\"name\":\"\",\"role\":\"user\"},\"locale\":\"en-US\",\"timestamp\":\"2020-01-20T19:23:58.484Z\",\"entities\":[{\"requiresBotState\":true,\"supportsListening\":true,\"supportsTts\":true,\"type\":\"ClientCapabilities\"}]}")
				.when().post("https://directline.botframework.com/v3/directline/conversations/"
						+ apiValues.get("conversationId") + "/activities")
				.then();
	}

	public void selectAnyEvent(String testinput) {
		String body = "{\"text\":\"" + testinput
				+ "\",\"textFormat\":\"plain\",\"type\":\"message\",\"channelData\":{\"oauthAccessToken\":\"" + OAuth
				+ "\",\"oauthProvider\":\"microsoft\"},\"channelId\":\"webchat\",\"from\":{\"id\":\""
				+ apiValues.get("userID") + "\",\"name\":\"\",\"role\":\"user\"},\"locale\":\"en-US\"}";
		Response response = given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").body(body).when()
				.post("https://directline.botframework.com/v3/directline/conversations/"
						+ apiValues.get("conversationId") + "/activities")
				.then().extract().response();
		apiValues.put("watermarkid", Arrays.asList(response.jsonPath().get("id").toString().split("[|]")).get(1));
	}

	public boolean verifyProductDetails(String validatetext) {
		Response response = given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid")).when()
				.get("https://directline.botframework.com/v3/directline/conversations/"
						+ apiValues.get("conversationId") + "/activities")
				.then().extract().response();
//		System.out.println("-->"+response.asString().replaceAll("[^a-zA-Z0-9]", "").toLowerCase()+"<--");
//		System.out.println("-->"+response.asString()+"<--");
		return response.asString().replaceAll("[^a-zA-Z0-9]", "").toLowerCase()
				.contains(validatetext.replaceAll("[^a-zA-Z0-9]", "").toLowerCase());
	}

	public boolean verifyContentInResponse(String validatetext) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		String response = "";
		try {
			response = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
		} catch (Exception e) {
		}
		if (response.toLowerCase().replaceAll("[^a-zA-Z0-9]", "")
				.contains(validatetext.toLowerCase().replaceAll("[^a-zA-Z0-9]", "")))
			return true;
		else
			return false;
	}

	public boolean verifypartialProductDetails(String validatetext, String productName) {
		Response response = given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid")).when()
				.get("https://directline.botframework.com/v3/directline/conversations/"
						+ apiValues.get("conversationId") + "/activities")
				.then().extract().response();
		if (response.asString().replaceAll("[^a-zA-Z0-9]", "").toLowerCase()
				.contains(validatetext.replaceAll("[^a-zA-Z0-9]", "").toLowerCase()))
			return true;
		else {
			int activitiesSize = response.jsonPath().getInt("activities.size()");
			int activityNumber = 0;
			try {
				for (int i = 0; i < activitiesSize; i++) {
					try {
						if (response.jsonPath().getInt("activities[" + i + "].attachments.size()") > 0) {
							activityNumber = i;
							break;
						}
					} catch (Exception e1) {

					}
				}
				int attachmentsize = response.jsonPath()
						.getInt("activities[" + activityNumber + "].attachments.size()");
				for (int i = 0; i < attachmentsize; i++) {
					System.out.println("-->" + Integer.parseInt(response.jsonPath()
							.get("activities[" + activityNumber + "].attachments[" + i + "].content.buttons.size()")
							.toString()));
					for (int j = 0; j < Integer.parseInt(response.jsonPath()
							.get("activities[" + activityNumber + "].attachments[" + i + "].content.buttons.size()")
							.toString()); j++) {
						if (response.jsonPath()
								.get("activities[" + activityNumber + "].attachments[" + i + "].content.buttons[" + j
										+ "].title")
								.toString().replaceAll("[^a-zA-Z0-9]", "")
								.equalsIgnoreCase(productName.replaceAll("[^a-zA-Z0-9]", ""))) {
							System.out.println("----->>>>" + response.jsonPath().get("activities[" + activityNumber
									+ "].attachments[" + i + "].content.buttons[" + j + "].value").toString());
							apiValues.put(Thread.currentThread().getName(),
									response.jsonPath().get(
											"activities[1].attachments[" + i + "].content.buttons[" + j + "].value")
											.toString());
							return false;
						}
					}
				}

			} catch (Exception e2) {
			}
			return false;
		}
	}

	public ArrayList verifypartialPartDetails(ArrayList partsData) {
		ArrayList temp = new ArrayList(partsData);
		String plainResponse = given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid")).when()
				.get("https://directline.botframework.com/v3/directline/conversations/"
						+ apiValues.get("conversationId") + "/activities")
				.then().extract().response().asString().toLowerCase().replaceAll("[^a-zA-Z0-9]", "");
		if (plainResponse.contains(partsData.get(0).toString().toLowerCase().replaceAll("[^a-zA-Z0-9]", ""))
				&& plainResponse.contains(partsData.get(1).toString().toLowerCase().replaceAll("[^a-zA-Z0-9]", ""))) {
			temp.add("PASS");
			temp.add("PASS");
		} else {
			temp.add("FAIL");
			temp.add("FAIL");
		}
		return temp;
	}

	public ArrayList verifyBulkpartialPartDetails(ArrayList partsData) {
		ArrayList temp = new ArrayList(partsData);
		String plainResponse = given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid")).when()
				.get("https://directline.botframework.com/v3/directline/conversations/"
						+ apiValues.get("conversationId") + "/activities")
				.then().extract().response().asString().toLowerCase().replaceAll("[^a-zA-Z0-9]", "");
		if (plainResponse.contains(partsData.get(1).toString().toLowerCase().replaceAll("[^a-zA-Z0-9]", ""))) {
			temp.add("PASS");
			temp.add("PASS");
		} else {
			temp.add("FAIL");
			temp.add("FAIL");
		}
		return temp;
	}

	public ArrayList verifypartialPartDetailsWithModel(ArrayList partsData) {
		ArrayList temp = new ArrayList(partsData);
		String plainResponse = given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid")).when()
				.get("https://directline.botframework.com/v3/directline/conversations/"
						+ apiValues.get("conversationId") + "/activities")
				.then().extract().response().asString().toLowerCase().replaceAll("[^a-zA-Z0-9]", "");
		if ((plainResponse.contains(partsData.get(0).toString().toLowerCase().replaceAll("[^a-zA-Z0-9]", ""))
				|| plainResponse.contains(partsData.get(1).toString().toLowerCase().replaceAll("[^a-zA-Z0-9]", "")))
				&& (plainResponse.contains(partsData.get(2).toString().toLowerCase().replaceAll("[^a-zA-Z0-9]", ""))
						&& plainResponse
								.contains(partsData.get(3).toString().toLowerCase().replaceAll("[^a-zA-Z0-9]", "")))) {
			temp.add("PASS");
			temp.add("PASS");
			temp.add("PASS");
		} else {
			temp.add("FAIL");
			temp.add("FAIL");
			temp.add("FAIL");
		}
		return temp;
	}

	public boolean getModelUtterance(String modelName, String alternate_model_name) {
		JsonPath jp;
		try {
			jp = given().header("Authorization", "Bearer " + apiValues.get("conversationToken")).header("Accept", "*/*")
					.header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("https://directline.botframework.com/v3/directline/conversations/"
							+ apiValues.get("conversationId") + "/activities")
					.then().extract().response().jsonPath();
		} catch (Exception e) {
			System.out.println("*********");
			return false;
		}
		if (alternate_model_name.toLowerCase().contains("Dishmachine: ".toLowerCase()))
			alternate_model_name = StringUtils.substringAfter(alternate_model_name, "Dishmachine: ").trim();
		else if (alternate_model_name.toLowerCase().contains("Dispenser: ".toLowerCase()))
			alternate_model_name = StringUtils.substringAfter(alternate_model_name, "Dispenser: ").trim();
		try {
			int attachmentSize = Integer.parseInt(jp.get("activities[0].attachments.size()").toString());
			for (int j = 0; j < attachmentSize; j++) {
				int buttonSize = Integer
						.parseInt(jp.get("activities[0].attachments[" + j + "].content.buttons.size()").toString());
				for (int i = 0; i < buttonSize; i++) {
					if (modelName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase().equalsIgnoreCase(
							jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].title").toString()
									.replaceAll("[^a-zA-Z0-9]", "").toLowerCase())
							|| alternate_model_name.replaceAll("[^a-zA-Z0-9]", "").toLowerCase().equalsIgnoreCase(
									jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].title")
											.toString().replaceAll("[^a-zA-Z0-9]", "").toLowerCase())) {
						System.out.println("modelUtterance----->>>>"
								+ jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].value")
										.toString());
						apiValues.put("modelUtterance",
								jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].value")
										.toString());
						return true;
					}
				}
			}
		} catch (Exception e2) {
			System.out.println("--->1.4");
			return false;
		}
		return false;
	}

	public boolean verifyCompleteProductDetails(String env, String testinput, String validatetext) {
		System.out.println(env + "--" + testinput + "--" + validatetext);
		try {
			directLineTokenGenerator(env);
			conversationTokenGenerator();
			activityEvent();
			selectAnyEvent(testinput);
			return verifyProductDetails(validatetext);
		} catch (Exception e) {
			return false;
		}
	}

	public boolean verifyPartialProductDetails(String env, String partialProductTestinput, String productName,
			String validatetext) {
		System.out.println(env + "--" + partialProductTestinput + "--" + productName + "--" + validatetext);
		try {
			directLineTokenGenerator(env);
			conversationTokenGenerator();
			activityEvent();
			selectAnyEvent(partialProductTestinput);
			if (verifypartialProductDetails(validatetext, productName))
				return true;
			else {
				selectAnyEvent(apiValues.get(Thread.currentThread().getName()));
				return verifyProductDetails(validatetext);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public ArrayList verifyPartsDetails(String env, ArrayList partsData) {
		System.out.println(env + "--" + partsData);
		try {
			directLineTokenGenerator(env);
			conversationTokenGenerator();
			activityEvent();
			selectAnyEvent(partsData.get(2).toString());
			return verifypartialPartDetails(partsData);
		} catch (Exception e) {
			partsData.add("FAIL");
			partsData.add("FAIL");
			return partsData;
		}
	}

	public ArrayList verifyBulkPartsDetails(String env, ArrayList partsData) {
		System.out.println(env + "--" + partsData);
		try {
			directLineTokenGenerator(env);
			conversationTokenGenerator();
			activityEvent();
			selectAnyEvent(partsData.get(2).toString());
			if (verifyContentInResponse("Add to My List"))
				return verifyBulkpartialPartDetails(partsData);
			else if (getModelUtterance(partsData.get(0).toString(), partsData.get(1).toString())) {
				selectAnyEvent(apiValues.get("modelUtterance"));
				return verifyBulkpartialPartDetails(partsData);
			}
		} catch (Exception e) {
			partsData.add("FAIL");
			partsData.add("FAIL");
			return partsData;
		}
		return partsData;
	}

	public ArrayList verifyPartsDetailsWithModelName(String env, ArrayList partsData) {
		System.out.println(env + "--" + partsData);
		try {
			directLineTokenGenerator(env);
			conversationTokenGenerator();
			activityEvent();
			selectAnyEvent(partsData.get(4).toString());
			if (verifyContentInResponse("Add to My List"))
				return verifypartialPartDetailsWithModel(partsData);
			else if (getModelUtterance(partsData.get(0).toString(), partsData.get(1).toString())) {
				selectAnyEvent(apiValues.get("modelUtterance"));
				return verifypartialPartDetailsWithModel(partsData);
			}
		} catch (Exception e) {
		}
		ArrayList temp = new ArrayList(partsData);
		temp.add("FAIL");
		temp.add("FAIL");
		temp.add("FAIL");
		return temp;
	}

	public ArrayList verifyPartsDetailsWithOnlyModelName(String env, ArrayList partsData) {
		System.out.println(env + "--" + partsData);
		try {
			directLineTokenGenerator(env);
			conversationTokenGenerator();
			activityEvent();
			selectAnyEvent(partsData.get(4).toString());
			if (verifyContentInResponse("Add to My List"))
				return verifypartialPartDetailsWithModel(partsData);
			else if (getModelUtterance(partsData.get(0).toString(), partsData.get(1).toString())) {
				selectAnyEvent(apiValues.get("modelUtterance"));
				return verifypartialPartDetailsWithModel(partsData);
			}
		} catch (Exception e) {
		}
		ArrayList temp = new ArrayList(partsData);
		temp.add("FAIL");
		temp.add("FAIL");
		temp.add("FAIL");
		return temp;
	}

	public String verifyAnnotatedImagesForParts(String env, String input, String imageurl) {
		System.out.println(env + "--" + input + "--" + imageurl);
		try {
			directLineTokenGenerator(env);
			conversationTokenGenerator();
			activityEvent();
			selectAnyEvent(input);
			if (verifyContentInResponse(imageurl))
				return "PASS";
			else
				return "FAIL";
		} catch (Exception e) {
			return "FAIL";
		}

	}
}
