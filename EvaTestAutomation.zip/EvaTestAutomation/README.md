The framework is developed using Page Object model Pattern using TestNG with Cucumber

All the java codes comes under src/test/java under which we have 10 packages:
1. acceptancetestpackage->It has runner file for execution
2. baseclass->Driver Initialization
3. common->Common Actions like Login
4. context->To Store Temporary Values
5. hooks->performs opening and closing browser before actual test starts
6. missions->multiple user actions should be added in missions
7. model-> User data model for serialization and deserialization using GSON
8. pages->Page Object model pattern
9. stepdefs->All stepdefs are present
10.utility->read data from property files

All no coding stuffs comes under src/test/resources
features->All feature files are present in this folder
config folder has 
* URL.properties file which has URL info
* DeviceCapabilities.json has device info to run on Android Device

Test Data Folder has all test execution files related to Parts and Products

In order to handle Driver files I have used WebDriverManager plugin which will automatically
download correpsonding driver based on browser used.

Maven Command to run the test is:
mvn clean test -Dcucumber.options="--tags @Smoke" -Denv="stage-inst"
- Denv can be:
* stage-inst
* dev-inst
* prod-inst

testngXML folder consists of folder related to testng.xml file based on browser type

HTML Report is generated using Cluecucumber Plugin and it will be available in target folder with file name starting with test-report