package com.test.baseclass;

import java.util.concurrent.TimeUnit;

import org.testng.Reporter;

import com.test.utility.GetPropertiesData;

public class BaseClass {
	public static BrowserFactory browserFactory = BrowserFactory.getInstance();
	public void launchBrowser() throws Exception {
		browserFactory.setDriver(
				Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browser"));
		browserFactory.setWait(browserFactory.getDriver(), 30);
		if(!(Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browser").equalsIgnoreCase("android")||Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browser").equalsIgnoreCase("iphone")))
		browserFactory.getDriver().manage().window().maximize();
		try
		{
		if(System.getProperty("env").equalsIgnoreCase("dev-inst"))
		browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("instdevurl"));
		else if (System.getProperty("env").equalsIgnoreCase("stage-inst"))
		browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("inststageurl"));	
		else if (System.getProperty("env").equalsIgnoreCase("prod-inst"))
		browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("instprodurl"));
		else if (System.getProperty("env").equalsIgnoreCase("prod-it"))
			browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("itprodurl"));
		else if (System.getProperty("env").equalsIgnoreCase("stage-it"))
			browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("itstageurl"));
		else if (System.getProperty("env").equalsIgnoreCase("dev-it"))
			browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("itdevurl"));
		else if (System.getProperty("env").equalsIgnoreCase("prod-it"))
		browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("itprodurl"));
		}
		catch(Exception e)
		{
			browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("instprodurl"));
		}
		browserFactory.getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
}