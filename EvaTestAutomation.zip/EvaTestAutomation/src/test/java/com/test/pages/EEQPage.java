package com.test.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.test.baseclass.BaseClass;

public class EEQPage extends BaseClass {
	@FindBy(xpath = "//*[@id='nav-dishmachines']//a/span")
	public List<WebElement> modelNames;

	@FindBy(xpath = "//div[@id='column_main']//h2//span")
	public List<WebElement> assemblyNames;

	@FindBy(xpath = "//span[.='By Dishmachine']")
	public WebElement dishmachinesTab;

	@FindBy(xpath = "//h2[@data-controlled]")
	public List<WebElement> listOfAssemblyNumbers;

	@FindBy(xpath = "//h2[@class='eco_c1 main_h2']")
	public WebElement alternateModelName;

	public EEQPage() {
		PageFactory.initElements(browserFactory.getDriver(), this);
	}

	public EEQPage clickOnDishmachinesTab() {
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(dishmachinesTab)).click();
		return this;
	}

	public EEQPage expandADStab() {
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(modelNames.get(0))).click();
		return this;
	}
}
