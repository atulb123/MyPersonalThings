package com.test.stepdefs;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.test.baseclass.BaseClass;
import com.test.common.ComonActions;
import com.test.context.Context;
import com.test.model.UserDataModel;
import com.test.pages.CommonPage;
import com.test.pages.ServiceNowPage;
import com.test.utility.GetUserData;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import com.test.missions.ITMission;

public class ITStepDefs extends BaseClass {
	private ITMission iTMission = new ITMission();
	private CommonPage commonPage = new CommonPage();
	private ServiceNowPage serviceNowPage = new ServiceNowPage();

	@Then("I should see same search results displayed as that of service now")
	public void i_should_see_same_search_results_displayed_as_that_of_service_now() {
		Assert.assertTrue(
				iTMission.getSearchResults(Context.tempValues.get(Thread.currentThread().getName()) != null
						? Context.tempValues.get(Thread.currentThread().getName())
						: Context.tempValues.get("inputText")),
				"EVA KB serach result is not matching with service now search result");
		browserFactory.getDriver().close();
		browserFactory.getDriver().switchTo().window(iTMission.parentWindow);
	}

	@Then("I should see a message {string} displayed in the application")
	public void i_should_see_a_message_displayed_in_the_application(String text) {
		Assert.assertTrue(browserFactory.getWait()
				.until(ExpectedConditions.attributeContains(By.xpath(
						"(//div[@class='webchat__row message']//*[contains(@aria-label,'" + text + "')])[last()]"),
						"aria-label", text)),
				"Article not found message is not displayed");
	}

	@Given("I Enter description of the ticket")
	public void i_Enter_description_of_the_ticket() {
		iTMission.enterTicketDescription();
	}

	@When("I Enter detailed description of the ticket")
	public void i_Enter_detailed_description_of_the_ticket() {
		iTMission.enterDetailedTicketDescription();
	}

	@Then("Application should display Successful ticket creation message with created date and description")
	public void application_should_display_Successful_ticket_creation_message_with_created_date_and_description()
			throws Throwable {
		Assert.assertTrue(browserFactory.getWait()
				.until(ExpectedConditions.textToBePresentInElementLocated(
						By.xpath("(//div[@class='webchat__row attachment']//*[contains(.,'"
								+ Context.tempValues.get("descriptionText") + "')])[last()]"),
						Context.tempValues.get("descriptionText"))),
				"Ticket Heading Not displayed");
		Assert.assertTrue(iTMission.verifyTicketCreationInServiceNow(), "Ticket not created in service now");
	}

	@Then("Application should display recent tickets with all the details")
	public void application_should_display_recent_tickets_with_all_the_details() {
		Assert.assertTrue(iTMission.verifyRecentTickets(), "Recent ticket list is not matching with service now");
	}

	@Given("I choose to provide comment for the first ticket displayed")
	public void i_choose_to_provide_comment_for_the_first_ticket_displayed() {
		Context.tempValues.put("ticketdescription", browserFactory.getWait()
				.until(ExpectedConditions.visibilityOf(commonPage.firstTicketTextBlock)).getText().trim());
		commonPage.selectFirstITTicket("Add a comment to this ticket");
	}

	@Then("I should see Corresponding Ticket should get updated as per the comments provided")
	public void i_should_see_Corresponding_Ticket_should_get_updated_as_per_the_comments_provided() {
		Assert.assertTrue(iTMission.verifyTicketIsUpdated(), "Ticket is not updated successfully");
	}

	@Given("I choose to resolve ticket for the last ticket displayed")
	public void i_choose_to_resolve_ticket_for_the_last_ticket_displayed() {
		Context.tempValues.put("ticketdescription", browserFactory.getWait()
				.until(ExpectedConditions.visibilityOf(commonPage.firstTicketTextBlock)).getText().trim());
		commonPage.clickResolveTicket();
	}

	@Then("I should see Corresponding Ticket is resolved and same is updated in servicenow")
	public void i_should_see_Corresponding_Ticket_is_resolved_and_same_is_updated_in_servicenow() {
		Assert.assertTrue(iTMission.verifyTicketIsResolved(), "Ticket is not resolved successfully");
		browserFactory.getDriver().close();
		browserFactory.getDriver().switchTo().window(iTMission.parentWindow);
	}

	@Then("I should see Corresponding Ticket is Assigned and same is updated in servicenow")
	public void i_should_see_Corresponding_Ticket_is_Assigned_and_same_is_updated_in_servicenow() {
		Assert.assertTrue(iTMission.verifyTicketIsAssigned(), "Ticket is not re-opned successfully");
	}

	@When("I Enter comment for the IT ticket")
	public void i_Enter_comment_for_the_IT_ticket() {
		String comment = "";
		for (int i = 0; i < 4; i++)
			comment = comment + RandomStringUtils.randomAlphabetic(50) + " ";
		comment = comment.trim();
		commonPage.enterText(comment);
		Context.tempValues.put("inputText", comment);
	}

	@Given("I get the ticketnumber of the recent ticket from servicenow")
	public void i_get_the_ticketnumber_of_the_recent_ticket_from_servicenow() {
		iTMission.getTicketNumberFromServiceNow();
	}

	@Given("I Enter the ticket number")
	public void i_Enter_the_ticket_number() {
		commonPage.enterText(Context.tempValues.get("ticketNumber"));
	}

	@Given("I choose to provide comment for the ticket displayed")
	public void i_choose_to_provide_comment_for_the_ticket_displayed() {
		iTMission.clickCommentButtonofSpecificTicket();
	}

	@Given("I Enter Update Ticket along with ticket number as input")
	public void i_Enter_Update_Ticket_along_with_ticket_number_as_input() {
		commonPage.enterText("update ticket " + Context.tempValues.get("ticketNumber"));
	}

	@When("I should see search article is redirecting to servicenow")
	public void i_should_see_search_article_is_redirecting_to_servicenow() {
		iTMission.checkKBSearchResultRedirection();
	}

	@When("I Enter input as {string} for the IT ticket")
	public void i_Enter_input_as_for_the_IT_ticket(String text) {
		commonPage.enterText(text);
		Context.tempValues.put("inputText", text);
	}

	@Given("I provide the input as {string} for the first ticket displayed")
	public void i_provide_the_input_as_for_the_first_ticket_displayed(String input) {
		Context.tempValues.put("ticketdescription", browserFactory.getWait()
				.until(ExpectedConditions.visibilityOf(commonPage.firstTicketTextBlock)).getText().trim());
		iTMission.getTicketNumberFromServiceNow();
		commonPage.enterText(input + " " + Context.tempValues.get("ticketNumber"));
	}

	@Given("I click on {string} for the first ticket displayed")
	public void i_click_on_for_the_first_ticket_displayed(String buttonText) {
		Context.tempValues.put("ticketdescription", browserFactory.getWait()
				.until(ExpectedConditions.visibilityOf(commonPage.firstApprovalTicketTextBlock)).getText().trim());
		browserFactory.getWait()
				.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("((//p[contains(.,'Here are your pending')])[last()]//..//..//..//..//..//button[.='"
								+ buttonText + "'])[1]")))
				.click();
	}

	@Then("I should see corresponding ticket gets {string}")
	public void i_should_see_corresponding_ticket_gets(String status) {
		Assert.assertTrue(iTMission.verifyTicketIsApp(status), "Failed to Approve the ticket");
	}

	@Given("I choose View Details for the  first recent resolved ticket displayed")
	public void i_choose_View_Details_for_the_first_recent_resolved_ticket_displayed() {
		Assert.assertTrue(
				browserFactory.getWait()
						.until(ExpectedConditions.visibilityOf(commonPage.firstRecentResolveTicketTextBlock)).getText()
						.trim().equals(Context.tempValues.get("ticketdescription")),
				"Latest Recent Resolved Ticket not displayed");
		Assert.assertTrue(iTMission.verifyRecentResolvedTicketDisplayed(),
				"Resove tikcet not displayed in service now");
		browserFactory.getDriver().close();
		browserFactory.getDriver().switchTo().window(iTMission.parentWindow);
	}

	@Given("I choose {string} for the first ticket displayed")
	public void i_choose_for_the_first_ticket_displayed(String text) {
		commonPage.selectFirstITTicket(text);
	}

	@Then("I should see main menu displayed again")
	public void i_should_see_main_menu_displayed_again() {
		browserFactory.getWait()
				.until(ExpectedConditions.numberOfElementsToBe(By.xpath("//p[contains(.,'help you')]"), 2));
	}
}
