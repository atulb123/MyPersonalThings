package com.test.missions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.test.baseclass.BaseClass;
import com.test.baseclass.BrowserFactory;
import com.test.context.Context;
import com.test.pages.CommonPage;
import com.test.pages.ServiceNowPage;
import com.test.utility.GetPropertiesData;

public class ITMission extends BaseClass {

	ServiceNowPage serviceNowPage = new ServiceNowPage();
	CommonPage commonPage = new CommonPage();
	public String parentWindow;

	public boolean getSearchResults(String searchText) {
		parentWindow = browserFactory.getDriver().getWindowHandle();
		List<String> EvaKBSearchResults = new ArrayList<String>();
		browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBeMoreThan(
				By.xpath("(//div[@class='content'])[last()]//li//div[contains(@style,'17')]//p"), 1));
		browserFactory.getDriver()
				.findElements(By.xpath("(//div[@class='content'])[last()]//li//div[contains(@style,'17')]//p")).stream()
				.forEach(e -> EvaKBSearchResults.add(e.getText()));
		commonPage.clickButton("Learn More");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		serviceNowPage.clickServiceNowLogo().enterTextInSearchBox(searchText).getSearchResults();
		return EvaKBSearchResults.stream().allMatch(
				result -> serviceNowPage.serviceNowSearchResult.contains(result.replaceAll("\\W", " ").trim()));
	}

	public ITMission enterTicketDescription() {
		String descriptionText = "";
		for (int i = 0; i < 6; i++)
			descriptionText = descriptionText + RandomStringUtils.randomAlphabetic(50) + " ";
		descriptionText = descriptionText.trim();
		commonPage.enterText(descriptionText);
		Context.tempValues.put("descriptionText", descriptionText.substring(0, 100));
		return this;
	}
	
	public ITMission enterDetailedTicketDescription() {
		String descriptionText = "";
		for (int i = 0; i < 6; i++)
			descriptionText = descriptionText + RandomStringUtils.randomAlphabetic(100) + " ";
		descriptionText = descriptionText.trim();
		commonPage.enterTxt(descriptionText);
		Context.tempValues.put("detailedDescription", descriptionText.substring(0, 150));
		return this;
	}

	public boolean verifyTicketCreationInServiceNow() throws Throwable {
		browserFactory.setWait(browserFactory.getDriver(), 30);
		parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.clickButton("View Details");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		return browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketPriority)).getText()
				.toLowerCase().contains("medium")
				&& browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketStatusTextBlock))
						.getText().toLowerCase().contains("new")
				&& browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketName)).getText()
						.toLowerCase().trim().contains(Context.tempValues.get("descriptionText").toLowerCase().trim());
	}

	public boolean verifyRecentTickets() {
		parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.clickMenuOption("View All Your Requests");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(serviceNowPage.ticketsTable));
		for (int i = 1; i <= serviceNowPage.ticketsTable.size(); i++) {
			Context.tempValues.put(
					browserFactory.getWait()
							.until(ExpectedConditions.visibilityOf(browserFactory.getDriver()
									.findElement(By.xpath("(//tr[contains(@ng-repeat,'data.list track')])[" + i
											+ "]//td[@data-field='sys_created_on']"))))
							.getText(),
					browserFactory.getWait()
							.until(ExpectedConditions.visibilityOf(browserFactory.getDriver()
									.findElement(By.xpath("(//tr[contains(@ng-repeat,'data.list track')])[" + i
											+ "]//td[@data-field='short_description']"))))
							.getText());
		}
		browserFactory.getDriver().switchTo().window(parentWindow);
		int i = 1;
		for (Entry<String, String> entry : Context.tempValues.entrySet()) {
			if (!entry.getKey().equals("inputText")) {
				Assert.assertTrue(browserFactory.getWait()
						.until(ExpectedConditions.textToBePresentInElementLocated(
								By.xpath("//div[@class='content']//li[" + i + "]//div[@class='ac-textBlock'][2]"),
								entry.getKey())));
				Assert.assertTrue(browserFactory.getWait()
						.until(ExpectedConditions.textToBePresentInElementLocated(
								By.xpath("//div[@class='content']//li[" + i + "]//div[@class='ac-textBlock'][1]"),
								entry.getValue())));
				i++;
			}
		}
		return true;
	}

	public boolean verifyTicketIsUpdated() {
		parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.selectFirstITTicket("View Details");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		return browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.commentTextBlock))
				.getText().trim().equals(Context.tempValues.get("inputText").trim())
				&& browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketName)).getText()
						.trim().equals(Context.tempValues.get("ticketdescription").trim());
	}

	public boolean verifyTicketIsResolved() {
		parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.selectFirstITTicket("View Details");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		return browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.resolvedNotesTextBlock))
				.getText().trim().equals(Context.tempValues.get("inputText").trim())
				&& browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketStatusTextBlock))
						.getText().trim().equals("Resolved")
				&& browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketName)).getText()
						.trim().equals(Context.tempValues.get("ticketdescription").trim());
	}

	public ITMission getTicketNumberFromServiceNow() {
		parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.selectFirstITTicket("View Details");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		Context.tempValues.put("ticketNumber",
				browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketNumber)).getText());
		browserFactory.getDriver().close();
		browserFactory.getDriver().switchTo().window(parentWindow);
		return this;
	}

	public ITMission clickCommentButtonofSpecificTicket() {
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(commonPage.ticketTextArea));
		commonPage.clickMenuOption("Comment");
		return this;
	}

	public ITMission checkKBSearchResultRedirection() {
		String searchTitle = browserFactory.getWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
				"//p[contains(.,'Here are the best matches')]/../../../../..//div[contains(@class,'adaptiveCard')]//p")))
				.getText().trim();
		parentWindow = browserFactory.getDriver().getWindowHandle();
		browserFactory.getWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
				"//p[contains(.,'Here are the best matches')]/../../../../..//div[contains(@class,'adaptiveCard')]//button")))
				.click();
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		Assert.assertTrue(
				browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.KBSearchResultText))
						.getText().trim().toLowerCase().equals(searchTitle.toLowerCase()),
				"KB Search Result is not redirecting to SERVICE NOW");
		browserFactory.getDriver().close();
		browserFactory.getDriver().switchTo().window(parentWindow);
		return this;
	}

	public boolean verifyTicketIsApp(String status) {
		parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.selectFirstITTicket("View Details");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		return browserFactory.getWait()
				.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//label[.='State']/..//div[contains(.,'" + status + "')]")))
				.isDisplayed()
				&& browserFactory.getWait()
						.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//div[@class='panel-body']//div[contains(.,'"
										+ Context.tempValues.get("ticketdescription") + "')]")))
						.isDisplayed();
	}

	public boolean verifyRecentResolvedTicketDisplayed() {
		parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.selectFirstITTicket("View Details");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		return browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketStatusTextBlock))
				.getText().trim().equals("Resolved")
				&& browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketName)).getText()
						.trim().equals(Context.tempValues.get("ticketdescription").trim());
	}

	public boolean verifyTicketIsAssigned() {
		parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.selectFirstITTicket("View Details");
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		return browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketStatusTextBlock))
				.getText().trim().equals("Assigned")
				&& browserFactory.getWait().until(ExpectedConditions.visibilityOf(serviceNowPage.ticketName)).getText()
						.trim().equals(Context.tempValues.get("ticketdescription").trim());
	}
}