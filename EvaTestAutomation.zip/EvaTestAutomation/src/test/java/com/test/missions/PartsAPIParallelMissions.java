package com.test.missions;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.apache.poi.hssf.util.HSSFColor;

import com.test.utility.ExcelUtils;
import com.test.utility.ProductAPICalls;
import com.test.utility.ProductAPIParallelCalls;

public class PartsAPIParallelMissions {
	public PartsAPIParallelMissions validatePartsUttrancesParallelyThroughAPI(String env) throws Throwable {
		List<ArrayList> partsData = new ArrayList<ArrayList>();
		List<ArrayList> updatedPartsData = new ArrayList<ArrayList>();
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			ArrayList temp = new ArrayList<String>();
			temp.add(ExcelUtils.getCellData("Sheet1", i, 0));
			temp.add(ExcelUtils.getCellData("Sheet1", i, 1));
			if (ExcelUtils.getCellData("Sheet1", 0, 2).contains("<partial_part_name>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 2).replaceAll("<partial_part_name>",
						getPartialPartName(ExcelUtils.getCellData("Sheet1", i, 1))));
			else if (ExcelUtils.getCellData("Sheet1", 0, 2).contains("<part_number>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 2).replaceAll("<part_number>",
						getPartialPartName(ExcelUtils.getCellData("Sheet1", i, 0))));
			else if (ExcelUtils.getCellData("Sheet1", 0, 2).contains("<part_name>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 2)
						.replaceAll("<part_name>", ExcelUtils.getCellData("Sheet1", i, 1)).replaceAll("-", " ")
						.replaceAll("[^a-zA-z0-9 ]", ""));
			partsData.add(temp);
		}
		partsData.stream().parallel().forEach(e -> {
			ArrayList temp = new ProductAPIParallelCalls().verifyPartsDetails(env, e);
			if (temp.contains("FAIL")) {
				temp = new ProductAPIParallelCalls().verifyPartsDetails(env, e);
				if (temp.contains("FAIL"))
					temp = new ProductAPIParallelCalls().verifyPartsDetails(env, e);
				updatedPartsData.add(temp);
			} else
				updatedPartsData.add(temp);
			System.out.println("No of Lines-->" + updatedPartsData.size());
		});
		System.out.println("partsData---" + partsData.size());
		System.out.println("updatedPartsData--" + updatedPartsData.size());
		for (int i = 0; i < updatedPartsData.size(); i++) {
			for (int j = 0; j < updatedPartsData.get(i).size(); j++) {
				if (updatedPartsData.get(i).get(j).toString().equalsIgnoreCase("pass"))
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j,
							HSSFColor.GREEN.index);
				else if (updatedPartsData.get(i).get(j).toString().equalsIgnoreCase("fail"))
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j,
							HSSFColor.RED.index);
				else
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j);
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		return this;
	}

	public String getPartialPartName(String partName) {
		partName = partName.replaceAll("-", " ").replaceAll("[^a-zA-z0-9 ]", "");
		String[] temp = partName.split(" ");
		if (temp.length <= 3)
			return partName;
		else
			return temp[0] + " " + temp[1] + " " + temp[2] + " " + temp[3];
	}

	public String getPartialName(String partName) {
		partName = partName.replaceAll("-", " ").replaceAll("[^a-zA-z0-9 ]", "");
		String[] temp = partName.split(" ");
		if (temp.length <= 2)
			return partName;
		else
			return temp[0] + " " + temp[1];
	}

	public PartsAPIParallelMissions verifyAssemblyDetailsWhenPartialNameIsGivenInParallelMode(String env)
			throws Throwable {
		ArrayList<String> model_name = new ArrayList<String>();
		ArrayList<String> alternate_model_name = new ArrayList<String>();
		ArrayList<ArrayList> assembly_name = new ArrayList<ArrayList>();
		ExcelUtils.setExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Assembly_Data.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1");) {
			for (int j = i; j <= getStepSize(i); j++) {
				model_name.add(ExcelUtils.getCellData("Sheet1", j, 0));
				model_name.add(ExcelUtils.getCellData("Sheet1", j, 0));
			}
			i = getStepSize(i);
		}

		return this;
	}

	public int getStepSize(int currentRowNo) throws Exception {
		int flag = 0;
		while (flag != 2 && currentRowNo != ExcelUtils.getLastRownNo("Sheet1") + 2) {
			if (!ExcelUtils.getCellData("Sheet1", currentRowNo, 0).equals(""))
				flag++;
			currentRowNo++;
		}
		int temp = currentRowNo - 2;
		System.out.println("Step SIze-->" + temp);
		return temp;
	}

	public PartsAPIParallelMissions validatePartsUttrancesAlongWithModelNameParallelyThroughAPI(String env)
			throws Throwable {
		List<ArrayList> partsData = new ArrayList<ArrayList>();
		List<ArrayList> updatedPartsData = new ArrayList<ArrayList>();
		ExcelUtils.setExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup_Model_Name.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			ArrayList temp = new ArrayList<String>();
			temp.add(ExcelUtils.getCellData("Sheet1", i, 0));
			temp.add(ExcelUtils.getCellData("Sheet1", i, 1));
			temp.add(ExcelUtils.getCellData("Sheet1", i, 2));
			temp.add(ExcelUtils.getCellData("Sheet1", i, 3));
			if (ExcelUtils.getCellData("Sheet1", 0, 4).contains("<partial_part_name>")
					&& ExcelUtils.getCellData("Sheet1", 0, 4).contains("<partial_model_name>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 4)
						.replaceAll("<partial_part_name>", getPartialPartName(ExcelUtils.getCellData("Sheet1", i, 3)))
						.replaceAll("<partial_model_name>", getPartialName(ExcelUtils.getCellData("Sheet1", i, 0))));
			else if (ExcelUtils.getCellData("Sheet1", 0, 4).contains("<part_name>")
					&& ExcelUtils.getCellData("Sheet1", 0, 4).contains("<model_name>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 4)
						.replaceAll("<part_name>",
								ExcelUtils.getCellData("Sheet1", i, 3).replaceAll("-", " ").replaceAll("[^a-zA-z0-9 ]",
										""))
						.replaceAll("<model_name>", ExcelUtils.getCellData("Sheet1", i, 0).replaceAll("-", " ")
								.replaceAll("[^a-zA-z0-9 ]", "")));
			partsData.add(temp);
		}
		partsData.stream().parallel().forEach(e -> {
			ArrayList temp = new ProductAPIParallelCalls().verifyPartsDetailsWithModelName(env, e);
			if (temp.contains("FAIL")) {
				temp = new ProductAPIParallelCalls().verifyPartsDetailsWithModelName(env, e);
				if (temp.contains("FAIL"))
					temp = new ProductAPIParallelCalls().verifyPartsDetailsWithModelName(env, e);
				updatedPartsData.add(temp);
			} else
				updatedPartsData.add(temp);
			System.out.println("No of Lines-->" + updatedPartsData.size());
		});
		System.out.println("partsData---" + partsData.size());
		System.out.println("updatedPartsData--" + updatedPartsData.size());
		for (int i = 0; i < updatedPartsData.size(); i++) {
			for (int j = 0; j < updatedPartsData.get(i).size(); j++) {
				if (updatedPartsData.get(i).get(j).toString().equalsIgnoreCase("pass"))
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j,
							HSSFColor.GREEN.index);
				else if (updatedPartsData.get(i).get(j).toString().equalsIgnoreCase("fail"))
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j,
							HSSFColor.RED.index);
				else
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j);
			}
		}
		ExcelUtils.closeExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup_Model_Name.xlsx");
		return this;
	}

	public PartsAPIParallelMissions validatePartsAnnotatedImagesParallelyThroughAPI(String env) throws Throwable {
		ExcelUtils.setExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Annotated_Images.xlsx");
		ArrayList<LinkedHashMap<String, String>> partsData = new ArrayList<LinkedHashMap<String, String>>();
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			LinkedHashMap<String, String> temp = new LinkedHashMap<String, String>();
			temp.put("part_number", ExcelUtils.getCellData("Sheet1", i, 0));
			temp.put("part_name", ExcelUtils.getCellData("Sheet1", i, 1));
			if (ExcelUtils.getCellData("Sheet1", i, 2).equalsIgnoreCase("null"))
				temp.put("image_url", "https://cds-evachat-inst");
			else
				temp.put("image_url", ExcelUtils.getCellData("Sheet1", i, 2));
			for (int uc = 3; uc <= ExcelUtils.getLastColumnNo("Sheet1", 0); uc = uc + 2) {
				if (ExcelUtils.getCellData("Sheet1", 0, uc).contains("<part_number>")) {
					temp.put("utterance_part_number", ExcelUtils.getCellData("Sheet1", 0, uc)
							.replaceAll("<part_number>", ExcelUtils.getCellData("Sheet1", i, 0)));
					temp.put("image_url_part_number", "NA");
				} else if (ExcelUtils.getCellData("Sheet1", 0, uc).contains("<part_name>")) {
					temp.put("utterance_part_name",
							ExcelUtils.getCellData("Sheet1", 0, uc).replaceAll("<part_name>",
									ExcelUtils.getCellData("Sheet1", i, 1).replaceAll("[^a-zA-Z0-9 ]", " ")
											.replaceAll("\\s{2,}", " ")));
					temp.put("image_url_part_name", "NA");
				}
			}
			partsData.add(temp);
		}
		partsData.stream().parallel().forEach(e -> {
			ProductAPIParallelCalls tempObj = new ProductAPIParallelCalls();
			if (e.containsKey("utterance_part_number")) {
				if (tempObj.verifyAnnotatedImagesForParts(env, e.get("utterance_part_number"), e.get("image_url"))
						.equalsIgnoreCase("PASS"))
					e.put("image_url_part_number", "PASS");
				else {
					if (tempObj.verifyAnnotatedImagesForParts(env, e.get("utterance_part_number"), e.get("image_url"))
							.equalsIgnoreCase("PASS"))
						e.put("image_url_part_number", "PASS");
					else
						e.put("image_url_part_number", tempObj.verifyAnnotatedImagesForParts(env,
								e.get("utterance_part_number"), e.get("image_url")));
				}
			}
			if (e.containsKey("utterance_part_name")) {
				if (tempObj.verifyAnnotatedImagesForParts(env, e.get("utterance_part_name"), e.get("image_url"))
						.equalsIgnoreCase("PASS"))
					e.put("image_url_part_name", "PASS");
				else {
					if (tempObj.verifyAnnotatedImagesForParts(env, e.get("utterance_part_name"), e.get("image_url"))
							.equalsIgnoreCase("PASS"))
						e.put("image_url_part_name", "PASS");
					else
						e.put("image_url_part_name", tempObj.verifyAnnotatedImagesForParts(env,
								e.get("utterance_part_name"), e.get("image_url")));
				}
			}
		});
		System.out.println("partsData---" + partsData.size());
		for (int i = 0; i < partsData.size(); i++) {
			int j = 0;
			for (Entry<String, String> e : partsData.get(i).entrySet()) {
				if (e.getValue().equalsIgnoreCase("PASS"))
					ExcelUtils.setCellData("Sheet1", e.getValue(), i + 1, j, HSSFColor.GREEN.index);
				else if (e.getValue().equalsIgnoreCase("FAIL"))
					ExcelUtils.setCellData("Sheet1", e.getValue(), i + 1, j, HSSFColor.RED.index);
				else
					ExcelUtils.setCellData("Sheet1", e.getValue(), i + 1, j);
				j++;
			}
		}
		ExcelUtils.closeExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Annotated_Images.xlsx");
		return this;
	}

	public PartsAPIParallelMissions validatePartsUttrancesOnlyWithModelNameParallelyThroughAPI(String env)
			throws Throwable {
		List<ArrayList> partsData = new ArrayList<ArrayList>();
		List<ArrayList> updatedPartsData = new ArrayList<ArrayList>();
		ExcelUtils.setExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup_Only_Model_Name.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			ArrayList temp = new ArrayList<String>();
			temp.add(ExcelUtils.getCellData("Sheet1", i, 0));
			temp.add(ExcelUtils.getCellData("Sheet1", i, 1));
			temp.add(ExcelUtils.getCellData("Sheet1", i, 2));
			temp.add(ExcelUtils.getCellData("Sheet1", i, 3));
			if (ExcelUtils.getCellData("Sheet1", 0, 4).contains("<partial_model_name>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 4).replaceAll("<partial_model_name>",
						getPartialName(ExcelUtils.getCellData("Sheet1", i, 0))));
			partsData.add(temp);
		}
		partsData.stream().parallel().forEach(e -> {
			ArrayList temp = new ProductAPIParallelCalls().verifyPartsDetailsWithOnlyModelName(env, e);
			if (temp.contains("FAIL")) {
				temp = new ProductAPIParallelCalls().verifyPartsDetailsWithOnlyModelName(env, e);
				if (temp.contains("FAIL"))
					temp = new ProductAPIParallelCalls().verifyPartsDetailsWithOnlyModelName(env, e);
				updatedPartsData.add(temp);
			} else
				updatedPartsData.add(temp);
			System.out.println("No of Lines-->" + updatedPartsData.size());
		});
		System.out.println("partsData---" + partsData.size());
		System.out.println("updatedPartsData--" + updatedPartsData.size());
		for (int i = 0; i < updatedPartsData.size(); i++) {
			for (int j = 0; j < updatedPartsData.get(i).size(); j++) {
				if (updatedPartsData.get(i).get(j).toString().equalsIgnoreCase("pass"))
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j,
							HSSFColor.GREEN.index);
				else if (updatedPartsData.get(i).get(j).toString().equalsIgnoreCase("fail"))
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j,
							HSSFColor.RED.index);
				else
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j);
			}
		}
		ExcelUtils.closeExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup_Only_Model_Name.xlsx");
		return this;
	}

	public PartsAPIParallelMissions validateBuldDispenserPartsUttrancesParallelyThroughAPI(String env) throws Throwable {
		List<ArrayList> partsData = new ArrayList<ArrayList>();
		List<ArrayList> updatedPartsData = new ArrayList<ArrayList>();
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			ArrayList temp = new ArrayList<String>();
			temp.add(ExcelUtils.getCellData("Sheet1", i, 0));
			temp.add(ExcelUtils.getCellData("Sheet1", i, 1));
			if (ExcelUtils.getCellData("Sheet1", 0, 2).contains("<partial_part_name>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 2).replaceAll("<partial_part_name>",
						getPartialPartName(ExcelUtils.getCellData("Sheet1", i, 1))));
			else if (ExcelUtils.getCellData("Sheet1", 0, 2).contains("<part_number>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 2).replaceAll("<part_number>",
						getPartialPartName(ExcelUtils.getCellData("Sheet1", i, 0))));
			else if (ExcelUtils.getCellData("Sheet1", 0, 2).contains("<part_name>"))
				temp.add(ExcelUtils.getCellData("Sheet1", 0, 2)
						.replaceAll("<part_name>", ExcelUtils.getCellData("Sheet1", i, 1)).replaceAll("-", " ")
						.replaceAll("[^a-zA-z0-9 ]", ""));
			partsData.add(temp);
		}
		partsData.stream().parallel().forEach(e -> {
			ArrayList temp = new ProductAPIParallelCalls().verifyBulkPartsDetails(env, e);
			if (temp.contains("FAIL")) {
				temp = new ProductAPIParallelCalls().verifyBulkPartsDetails(env, e);
				if (temp.contains("FAIL"))
					temp = new ProductAPIParallelCalls().verifyBulkPartsDetails(env, e);
				updatedPartsData.add(temp);
			} else
				updatedPartsData.add(temp);
			System.out.println("No of Lines-->" + updatedPartsData.size());
		});
		System.out.println("partsData---" + partsData.size());
		System.out.println("updatedPartsData--" + updatedPartsData.size());
		for (int i = 0; i < updatedPartsData.size(); i++) {
			for (int j = 0; j < updatedPartsData.get(i).size(); j++) {
				if (updatedPartsData.get(i).get(j).toString().equalsIgnoreCase("pass"))
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j,
							HSSFColor.GREEN.index);
				else if (updatedPartsData.get(i).get(j).toString().equalsIgnoreCase("fail"))
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j,
							HSSFColor.RED.index);
				else
					ExcelUtils.setCellData("Sheet1", updatedPartsData.get(i).get(j).toString(), i + 1, j);
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		return this;
	}
}
