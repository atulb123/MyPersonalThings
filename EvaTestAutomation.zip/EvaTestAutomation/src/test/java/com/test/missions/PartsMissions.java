package com.test.missions;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.HSSFColor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.test.baseclass.BaseClass;
import com.test.context.Context;
import com.test.pages.CommonPage;
import com.test.pages.EEQPage;
import com.test.pages.ProductsPage;
import com.test.utility.ExcelUtils;

import io.cucumber.datatable.DataTable;

public class PartsMissions extends BaseClass {
	private CommonPage commonPage = new CommonPage();
	private EEQPage eeqPage = new EEQPage();

	public boolean verifyPartsList(String partName) {
		return browserFactory.getWait()
				.until(ExpectedConditions
						.visibilityOfAllElementsLocatedBy(By.xpath("//span[@aria-label='Top Results']/../../../..//p")))
				.stream().filter(e -> e.getText().toLowerCase().contains(partName.toLowerCase())).findFirst().get()
				.isDisplayed();
	}

	public PartsMissions searchPart() throws Throwable {
		int temp = 1;
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Search.xlsx");
		int part_Lookup_Menu = 1;
		int part_Category_Menu = 1;
		int what_specific_part = 1;
		int what_else_can_i_help = 1;
		int part_carousel = 1;
		int start_over = 1;

		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i = i + 2) {
			System.out.println("Remaining Parts to Test-->" + (((ExcelUtils.getLastRownNo("Sheet1")) - i) / 2));
			for (int j = 2; j < ExcelUtils.getLastColumnNo("Sheet1", i); j++) {
				if (!(ExcelUtils.getCellData("Sheet1", i, j) == null
						|| ExcelUtils.getCellData("Sheet1", i, j).equals(""))) {
					try {
						browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(
								By.xpath("(//button[contains(@aria-label,'Lookup Part')])"), part_Lookup_Menu));
						commonPage.clickMenuOption("Lookup Part");
						part_Lookup_Menu++;
						browserFactory.getWait().until(ExpectedConditions
								.numberOfElementsToBe(By.xpath("//p[.='Select a Part category']"), part_Category_Menu));
						part_Category_Menu++;
						if (ExcelUtils.getCellData("Sheet1", i, 1).equalsIgnoreCase("eco_dispenser"))
							commonPage.clickMenuOption("Dispenser");
						else if (ExcelUtils.getCellData("Sheet1", i, 1).equalsIgnoreCase("eco_dishmachine"))
							commonPage.clickMenuOption("Dishmachine");
						else
							commonPage.clickMenuOption("General Parts");
						browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(
								By.xpath("//p[contains(.,'What specific part name')]"), what_specific_part));
						commonPage.verifyMessageFromChatBot("What specific part name");
						what_specific_part++;
						commonPage.enterTxt(ExcelUtils.getCellData("Sheet1", i, j));
						String expectedPartName = ExcelUtils.getCellData("Sheet1", i, 0);
						browserFactory.getWait().until(ExpectedConditions
								.numberOfElementsToBe(By.xpath("//p[.='Top Results']"), part_carousel));
						part_carousel++;
						browserFactory.getWait()
								.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
										By.xpath("(//p[.='Top Results'])[last()]//..//..//..//..//..//p")))
								.stream().filter(e -> e.getText().toLowerCase().trim()
										.equals(expectedPartName.toLowerCase().trim()))
								.findFirst().get().isDisplayed();
						ExcelUtils.setCellData("Sheet1", "PASS", i + 1, j, HSSFColor.GREEN.index);
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("-->catch block 1");
						ExcelUtils.setCellData("Sheet1", "FAIL", i + 1, j, HSSFColor.RED.index);
					}
					try {
						browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(
								By.xpath("//p[.='What else can I help you with?']"), what_else_can_i_help));
						what_else_can_i_help++;
					} catch (Exception e) {
						System.out.println("-->catch block 2");
						commonPage.enterTxt("cancel");
						commonPage.clickOption("Yes");
						browserFactory.getWait().until(ExpectedConditions
								.numberOfElementsToBe(By.xpath("//p[contains(.,'start over.')]"), start_over));
						start_over++;
						commonPage.enterTxt("Main Menu");
						what_else_can_i_help++;
					}

					try {
						if (temp == 1) {
							browserFactory.getWait()
									.until(ExpectedConditions
											.elementToBeClickable(By.xpath("//button//nobr[.='Onboarding Help']")))
									.isDisplayed();
							temp++;
						} else
							browserFactory.getWait()
									.until(ExpectedConditions
											.elementToBeClickable(By.xpath("//button//nobr[.='Feedback']")))
									.isDisplayed();
					} catch (Exception e) {
						System.out.println("-->catch block 3");
					}
				}
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Search.xlsx");
		return this;
	}

	public PartsMissions PartsLookup() throws Throwable {
		int temp = 1;
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		int part_carousel = 1;
		int start_over = 1;

		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			System.out.println("Remaining Parts to Test-->" + (((ExcelUtils.getLastRownNo("Sheet1")) - i)));
			for (int j = 4; j < ExcelUtils.getLastColumnNo("Sheet1", i); j++) {
				int flag = 1;
				try {
					String expectedPartName = ExcelUtils.getCellData("Sheet1", i, 1).trim();
					String expectedPartNumber = ExcelUtils.getCellData("Sheet1", i, 0).trim();
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<part name>"))
						commonPage.enterTxt(ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("[-]", " ")
								.replaceAll("<part name>", expectedPartName)
								.replaceAll("<category>", ExcelUtils.getCellData("Sheet1", i, 2))
								.replaceAll("[^a-zA-z0-9 ]", ""));
					else if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<part number>"))
						commonPage.enterTxt(ExcelUtils.getCellData("Sheet1", 0, j)
								.replaceAll("<part number>", expectedPartNumber).replaceAll("[^a-zA-z0-9 ]", ""));
					else if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial part name>"))
						commonPage.enterTxt(ExcelUtils.getCellData("Sheet1", 0, j)
								.replaceAll("<partial part name>", expectedPartName.split(" ")[0])
								.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", ""));
					browserFactory.getWait().until(
							ExpectedConditions.numberOfElementsToBe(By.xpath("//p[.='Top Results']"), part_carousel));
					part_carousel++;
					browserFactory.getWait()
							.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
									By.xpath("(//p[.='Top Results'])[last()]//..//..//..//..//..//p")))
							.stream()
							.filter(e -> e.getText().toLowerCase().trim().equals(expectedPartName.toLowerCase().trim()))
							.findFirst().get().isDisplayed();
					browserFactory.getWait()
							.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
									By.xpath("(//p[.='Top Results'])[last()]//..//..//..//..//..//p")))
							.stream().filter(e -> e.getText().toLowerCase().trim()
									.equals(expectedPartNumber.toLowerCase().trim()))
							.findFirst().get().isDisplayed();
					if (ExcelUtils.getCellData("Sheet1", i, 3).trim().equalsIgnoreCase("y"))
						browserFactory.getWait()
								.until(ExpectedConditions.visibilityOfElementLocated(
										By.xpath("(//p[.='Top Results'] )[last()]/../../../../..//p[.='"
												+ expectedPartNumber + "']/../..//img")));
					ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
				} catch (Exception e) {
					flag = 0;
					e.printStackTrace();
					System.out.println("-->catch block 1");
					ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					try {
						commonPage.enterTxt("cancel");
						commonPage.clickOption("Yes");
						browserFactory.getWait().until(ExpectedConditions
								.numberOfElementsToBe(By.xpath("//p[contains(.,'start over.')]"), start_over));
						start_over++;
					} catch (Exception e1) {
						System.out.println("-->inner catch block 1.1");
					}
				}
				if (flag == 1) {
					try {
						if (temp == 1) {
							browserFactory.getWait()
									.until(ExpectedConditions
											.elementToBeClickable(By.xpath("//button//nobr[.='Onboarding Help']")))
									.isDisplayed();
							temp++;
						} else
							browserFactory.getWait()
									.until(ExpectedConditions
											.elementToBeClickable(By.xpath("//button//nobr[.='Feedback']")))
									.isDisplayed();
					} catch (Exception e) {
						System.out.println("-->inner catch block 2");
					}
				}
			}

		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		return this;
	}

	public PartsMissions getPartsData() throws Throwable {
		eeqPage.clickOnDishmachinesTab().expandADStab();
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		int row_no = 1;
//	 eeqPage.modelNames.size()
		for (int i = 2; i <= 2; i++) {
			try {
				System.out.println("Model Name-->" + eeqPage.modelNames.get(i).getText());
				commonPage.clickByJavaScript(eeqPage.modelNames.get(i));
				String alternateModelName = StringUtils
						.substringAfter(
								browserFactory.getWait()
										.until(ExpectedConditions.visibilityOf(eeqPage.alternateModelName)).getText(),
								"Dishmachine: ")
						.trim();
				for (int j = 0; j < eeqPage.assemblyNames.size(); j++) {
					System.out.println("Assembly Name-->" + eeqPage.assemblyNames.get(j).getText());
					String assembly_id = StringUtils
							.substringAfter(eeqPage.listOfAssemblyNumbers.get(j).getAttribute("data-controlled"), "#")
							.trim();
					commonPage.clickByJavaScript(eeqPage.assemblyNames.get(j));
					Thread.sleep(3000);
					List<WebElement> partDetails = browserFactory.getDriver().findElements(
							By.xpath("//div[@id='" + assembly_id + "']//td[contains(@class,'prod_code')]//div"));
					for (int k = 0; k < partDetails.size(); k++) {
						ExcelUtils.setCellData("Sheet1", eeqPage.modelNames.get(i).getText(), row_no, 0);
						ExcelUtils.setCellData("Sheet1", alternateModelName, row_no, 1);
						ExcelUtils.setCellData("Sheet1", eeqPage.assemblyNames.get(j).getText(), row_no, 2);
						System.out.println("Part details-->" + partDetails.get(k).getText() + "--"
								+ browserFactory.getDriver().findElements(By.xpath(
										"//div[@id='" + assembly_id + "']//td[contains(@class,'description')]//a"))
										.get(k).getText());
						ExcelUtils.setCellData("Sheet1", partDetails.get(k).getText(), row_no, 3);
						ExcelUtils.setCellData("Sheet1", browserFactory.getDriver()
								.findElements(By.xpath(
										"//div[@id='" + assembly_id + "']//td[contains(@class,'description')]//a"))
								.get(k).getText(), row_no, 4);
						if (browserFactory.getDriver()
								.findElements(By.xpath("//div[@id='" + assembly_id
										+ "']//td[contains(@class,'icons')]//div[@class='icon_18 camera']"))
								.get(k).getAttribute("style").contains("hidden"))
							ExcelUtils.setCellData("Sheet1", "No", row_no, 5);
						else
							ExcelUtils.setCellData("Sheet1", "Yes", row_no, 5);
						try {
							System.out.println("Img url-->" + browserFactory.getDriver()
									.findElement(By.xpath("//div[@id='" + assembly_id + "']//img"))
									.getAttribute("src"));
							ExcelUtils.setCellData("Sheet1", browserFactory.getDriver()
									.findElement(By.xpath("//div[@id='" + assembly_id + "']//img")).getAttribute("src"),
									row_no, 6);
						} catch (Exception e123) {
							ExcelUtils.setCellData("Sheet1", "NULL", row_no, 6);
						}
						row_no++;
					}
					commonPage.clickByJavaScript(eeqPage.assemblyNames.get(j));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		return this;
	}

	public PartsMissions getAssemblyData() throws Throwable {
		eeqPage.clickOnDishmachinesTab().expandADStab();
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		int row_no = 1;
		// eeqPage.modelNames.size()
		for (int i = 60; i < eeqPage.modelNames.size(); i++) {
			System.out.println("Model Name-->" + eeqPage.modelNames.get(i).getText());
			browserFactory.getWait().until(ExpectedConditions.visibilityOf(eeqPage.modelNames.get(i))).click();
			ExcelUtils.setCellData("Sheet1", eeqPage.modelNames.get(i).getText(), row_no, 0);
			ExcelUtils.setCellData(
					"Sheet1", browserFactory.getWait()
							.until(ExpectedConditions.visibilityOf(eeqPage.alternateModelName)).getText().trim(),
					row_no, 1);
			for (int j = 0; j < eeqPage.assemblyNames.size(); j++) {
				System.out.println("Assembly Name-->" + eeqPage.assemblyNames.get(j).getText());
				ExcelUtils.setCellData("Sheet1", eeqPage.assemblyNames.get(j).getText(), row_no, 2);
				row_no++;
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		return this;
	}

	public boolean selectRandomPartFromList(DataTable table) {
		ArrayList<String> partNames = new ArrayList<String>();
		ArrayList<String> partsDetails = new ArrayList<String>();
		for (int i = 0; i < table.asList().size(); i++) {
			commonPage.enterText(table.asList().get(i));
			browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(
					By.xpath("//div[contains(@class,'webchat__carousel_indented_content')]"), i + 1));
			int partIndex = new Random().nextInt(commonPage.addToMyListButtons.size());
			partNames.add(browserFactory.getDriver().findElement(By.xpath(
					"(((//div[contains(@class,'webchat__carousel_indented_content')])[last()]//div[contains(@class,'adaptiveCard')])["
							+ (partIndex + 1) + "]//p)[1]"))
					.getText());
			System.out.println("Part Name-->" + partNames.get(partNames.size() - 1));
			commonPage.clickByJavaScript(commonPage.addToMyListButtons.get(partIndex));
			browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(
					By.xpath("//p[contains(.,'" + partNames.get(partNames.size() - 1) + " has been added')]"), 1));
			Context.tempValues.put(browserFactory.getDriver().findElement(By.xpath(
					"(((//div[contains(@class,'webchat__carousel_indented_content')])[last()]//div[contains(@class,'adaptiveCard')])["
							+ (partIndex + 1) + "]//p)[2]"))
					.getText(),
					browserFactory.getDriver().findElement(By.xpath(
							"(((//div[contains(@class,'webchat__carousel_indented_content')])[last()]//div[contains(@class,'adaptiveCard')])["
									+ (partIndex + 1) + "]//p)[1]"))
							.getText());
		}
		commonPage.clickHamBurgerIconAndSelectMenu("View My List");
		Context.tempValues.remove("inputText");
		commonPage.viewMyListAdaptiveCardsTextLabel.stream().forEach(e -> partsDetails.add(e.getText()));
		System.out.println("partNames->" + partNames);
		System.out.println("partsDetails->" + partsDetails);
		Assert.assertTrue(partNames.stream().allMatch(e -> partsDetails.contains(e)), "Part Names not displayed");
		commonPage.clickByJavaScript(browserFactory.getDriver().findElement(
				By.xpath("//p[.='" + partNames.get(partNames.size() - 1) + "']/../../../..//button[.='Remove']")));
		commonPage.verifyMessageFromChatBot(partNames.get(partNames.size() - 1));
		commonPage.clickOption("Yes");
		commonPage.verifylastMessageFromBot("What else can I help you");
		commonPage.clickHamBurgerIconAndSelectMenu("View My List");
		browserFactory.getWait()
				.until(ExpectedConditions.numberOfElementsToBe(By.xpath("//p[contains(.,'Here are the part')]"), 2));
		return commonPage.viewMyListAdaptiveCardsTextLabel.stream()
				.allMatch(e -> !e.getText().equals(partNames.get(partNames.size() - 1)));
	}

	public PartsMissions clickSamePartTwice() {
		for (int i = 0; i < 2; i++) {
			commonPage.clickButton("Add to My List");
			browserFactory.getWait().until(
					ExpectedConditions.numberOfElementsToBe(By.xpath("//p[contains(.,'has been added')]"), i + 1));
		}
		commonPage.enterText("View My List");
		return this;
	}
}
