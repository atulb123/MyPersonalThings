package com.test.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.baseclass.BaseClass;


public class ProductsPage extends BaseClass{

	@FindBy(xpath = "//p[contains(.,'Top Results')]/../../..//button")
	public List<WebElement> productButtons;

	public ProductsPage() {
		PageFactory.initElements(browserFactory.getDriver(), this);
	}
}
