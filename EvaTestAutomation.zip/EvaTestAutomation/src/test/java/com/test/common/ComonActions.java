package com.test.common;

import org.openqa.selenium.support.ui.ExpectedConditions;

import com.test.baseclass.BaseClass;
import com.test.model.UserDataModel;
import com.test.pages.CommonPage;
import com.test.pages.LoginPage;
import com.test.pages.PasswordPage;
import com.test.utility.GetUserData;

public class ComonActions extends BaseClass {
	private LoginPage loginPage = new LoginPage();
	private PasswordPage passwordPage = new PasswordPage();
	private CommonPage commonPage = new CommonPage();

	public ComonActions performLogin(String userName, String password) {
		loginPage.enterUserName(userName).clickNextButton();
		passwordPage.enterPassword(password).clickNextButton();
		try {
			browserFactory.getWait().until(ExpectedConditions.visibilityOf(commonPage.welcomeMessageTextBlock));
		} catch (Exception e) {
			try {
				passwordPage.clickAcceptButton();

			} catch (Exception e1) {
			}
		}
		browserFactory.getWait().until(ExpectedConditions.visibilityOf(commonPage.welcomeMessageTextBlock));
		return this;
	}
}