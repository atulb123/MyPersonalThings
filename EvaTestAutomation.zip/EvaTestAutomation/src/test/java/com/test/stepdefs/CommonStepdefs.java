package com.test.stepdefs;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.html5.WebStorage;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.test.baseclass.BaseClass;
import com.test.common.ComonActions;
import com.test.context.Context;
import com.test.hooks.Hook;
import com.test.model.UserDataModel;
import com.test.pages.CommonPage;
import com.test.utility.GetPropertiesData;
import com.test.utility.GetUserData;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CommonStepdefs extends BaseClass {

	private CommonPage commonPage = new CommonPage();
	private ComonActions comonActions = new ComonActions();
	private GetUserData getUserData = new GetUserData();

	@Then("I should see a CEO's information displayed")
	public void i_should_see_a_CEO_s_information_displayed() {
		Assert.assertTrue(browserFactory.getWait()
				.until(ExpectedConditions.visibilityOf(commonPage.ceoDescriptionTextBlock)).isDisplayed(),
				"CEO information is not displayed");
	}

	@Then("I should see text block containing {string} displayed")
	public void i_should_see_text_block_containing_displayed(String text) {
		Assert.assertTrue(commonPage.verifyTextBlockIsDisplayed(text),
				"Text Block containing " + text + " is not displayed");
	}

	@When("I provide then I should see same question being displayed")
	public void i_provide_then_I_should_see_same_question_being_displayed(DataTable dataTable) {
		for (int i = 0; i < dataTable.asList().size(); i++) {
			commonPage.enterText(dataTable.asList().get(i));
			Assert.assertTrue(browserFactory.getWait()
					.until(ExpectedConditions.numberOfElementsToBe(
							By.xpath("//p[contains(.,'How would you rate your experience')]"), i + 2))
					.size() == i + 2, "Mismatch in Feedback flow");
		}
	}

	@Given("I get the OAUth token from the Application for {string}")
	public void i_get_the_OAUth_token_from_the_Application_for(String userType) throws Throwable {
		UserDataModel userData = getUserData.getTestData(userType);
		comonActions.performLogin(userData.getUserName(), userData.getPassword());
		WebStorage webStorage = (WebStorage) new Augmenter().augment(browserFactory.getDriver());
		Context.tempValues.put("OAuth", webStorage.getSessionStorage().getItem("MICROSOFT_GRAPH_OAUTH_ACCESS_TOKEN"));
		System.out.println("oAuth--->" + Context.tempValues.get("OAuth"));
		browserFactory.removeDriver();
	}

	@Then("I should see {string} message sent by bot")
	public void i_should_see_message_sent_by_bot(String message) {
		Assert.assertTrue(commonPage.verifylastMessageFromBot(message),
				"Message containing text as " + message + " is not displayed");
	}

	@Then("I should see element {string} displayed")
	public void i_should_see_element_displayed(String locator) {
		Assert.assertTrue(commonPage.verifyElementDisplayed(locator), "Locator " + locator + " is not displayed");
	}
}
