package com.test.missions;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.poi.hssf.util.HSSFColor;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.test.pages.CommonPage;
import com.test.utility.ExcelUtils;
import com.test.utility.ProductAPICalls;
import com.test.utility.ProductAPIParallelCalls;

public class ProductAPIParallelMissions {
	CommonPage commonPage = new CommonPage();
	List<String> productNames = new ArrayList<String>();

	public ProductAPIParallelMissions validateProductUttrancesParallelyThroughAPI(String env) throws Throwable {
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Product_Lookup.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++)
			productNames.add(ExcelUtils.getCellData("Sheet1", i, 0).replaceAll("[-]", " ")
					.replaceAll("[^a-zA-z0-9 ]", " ").replaceAll("[\\s]{2,}", " "));
		for (int i = 1; i <= ExcelUtils.getLastColumnNo("Sheet1", 0); i++) {
			Map<String, String> tempValues = new TreeMap<String, String>();
			if (ExcelUtils.getCellData("Sheet1", 0, i).contains("<partial product name>")) {
				if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Dosage".toLowerCase()))
						&& (!ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("verify".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Dosage of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Dosage of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Dosage of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}
					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("FAQ".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("ESS".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase()
								.contains("frequently asked question".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("switch".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Frequently Asked Questions - Document on ESS"))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Frequently Asked Questions - Document on ESS"))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Frequently Asked Questions - Document on ESS"))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Technical".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("tech info".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Technical Information of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Technical Information of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Technical Information of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Ordering".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Ordering information of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Ordering information of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Ordering information of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Specification".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("PSD".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase()
								.contains("spec sheet".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Specification of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Specification of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Specification of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("SDS".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase()
								.contains("Safety Data Sheet".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Safety data".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase()
								.contains("Safety Sheet".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Safety Data Sheet of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Safety Data Sheet of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Safety Data Sheet of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Adjust".toLowerCase())) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Adjust a Dispenser of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Adjust a Dispenser of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Adjust a Dispenser of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Video".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("verify".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Verify Product Dosage of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Verify Product Dosage of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Verify Product Dosage of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Find <".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Get <".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
								utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
								"Dosage of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
									utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
									"Dosage of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyPartialProductDetails(env,
										utterance.replaceAll("<partial product name>", getPartialProductName(e)), e,
										"Dosage of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}
			} else {
				if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Dosage".toLowerCase()))
						&& (!ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("verify".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e), "Dosage of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e), "Dosage of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e), "Dosage of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("FAQ".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("ESS".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase()
								.contains("frequently asked question".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("switch".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e),
								"Frequently Asked Questions - Document on ESS"))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e),
									"Frequently Asked Questions - Document on ESS"))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e),
										"Frequently Asked Questions - Document on ESS"))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Technical".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("tech info".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e), "Technical Information of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e), "Technical Information of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e), "Technical Information of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Ordering".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e), "Ordering information of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e), "Ordering information of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e), "Ordering information of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}
					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Specification".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("PSD".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase()
								.contains("spec sheet".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e), "Specification of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e), "Specification of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e), "Specification of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}
					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("SDS".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase()
								.contains("Safety Data Sheet".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Safety data".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase()
								.contains("Safety Sheet".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e), "Safety Data Sheet of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e), "Safety Data Sheet of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e), "Safety Data Sheet of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}
					});
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Adjust".toLowerCase())) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e), "Adjust a Dispenser of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e), "Adjust a Dispenser of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e), "Adjust a Dispenser of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}

					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Video".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("verify".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e), "Verify Product Dosage of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e), "Verify Product Dosage of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e), "Verify Product Dosage of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}
					});
				}

				else if ((ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Find <".toLowerCase()))
						|| (ExcelUtils.getCellData("Sheet1", 0, i).toLowerCase().contains("Get <".toLowerCase()))) {
					String utterance = ExcelUtils.getCellData("Sheet1", 0, i);
					productNames.stream().parallel().forEach(e -> {
						if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
								utterance.replaceAll("<product name>", e), "Dosage of " + e))
							tempValues.put(e, "PASS");
						else {
							if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
									utterance.replaceAll("<product name>", e), "Dosage of " + e))
								tempValues.put(e, "PASS");
							else {
								if (new ProductAPIParallelCalls().verifyCompleteProductDetails(env,
										utterance.replaceAll("<product name>", e), "Dosage of " + e))
									tempValues.put(e, "PASS");
								else
									tempValues.put(e, "FAIL");
							}
						}
					});
				}
				System.out.println("No of Lines-->"+tempValues.size());
			}
			int count = 1;
			for (Entry<String, String> e : tempValues.entrySet()) {
				if (e.getValue().equalsIgnoreCase("pass")) {
					ExcelUtils.setCellData("Sheet1", e.getKey(), count, 0);
					ExcelUtils.setCellData("Sheet1", "PASS", count, i, HSSFColor.GREEN.index);
				} else {
					ExcelUtils.setCellData("Sheet1", e.getKey(), count, 0);
					ExcelUtils.setCellData("Sheet1", "FAIL", count, i, HSSFColor.RED.index);
				}
				count++;
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Product_Lookup.xlsx");
		return this;
	}

	public String getPartialProductName(String productName) {
		String[] temp = productName.split(" ");
		String partialProductName = "";
		if (temp.length <= 4)
			return productName;
		else
			return temp[0]+" "+temp[1]+" "+temp[2]+" "+temp[3]+" "+temp[4];
		}
	}

