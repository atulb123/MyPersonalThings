package com.test.missions;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Color;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.test.baseclass.BaseClass;
import com.test.context.Context;
import com.test.pages.CommonPage;
import com.test.pages.ESSPage;
import com.test.pages.ProductsPage;
import com.test.utility.ExcelUtils;
import com.test.utility.GetPropertiesData;

public class ProductsMission extends BaseClass {

	private CommonPage commonPage = new CommonPage();
	private ProductsPage productsPage = new ProductsPage();
	private ESSPage essPage = new ESSPage();

	public boolean verifyTechincalInformation(String menuText) {
		String parentWindow = browserFactory.getDriver().getWindowHandle();
		commonPage.clickMenuOption(menuText);
		for (String window : browserFactory.getDriver().getWindowHandles()) {
			if (!window.equals(parentWindow)) {
				browserFactory.getDriver().switchTo().window(window);
				break;
			}
		}
		browserFactory.getWait().until(ExpectedConditions.urlContains(menuText));
		Context.tempValues.put("url", browserFactory.getDriver().getCurrentUrl());
		browserFactory.getDriver().close();
		browserFactory.getDriver().switchTo().window(parentWindow);
		return Context.tempValues.get("url").contains(menuText);
	}

	public ProductsMission selectFirstProductFromList(String productName) {
		Context.tempValues.put("productName",
				browserFactory.getWait().until(ExpectedConditions.visibilityOfAllElements(productsPage.productButtons))
						.stream().filter(e -> e.getText().toLowerCase().contains(productName.toLowerCase())).findFirst()
						.get().getText());
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
				browserFactory.getDriver().findElement(By
						.xpath("(//button[contains(@aria-label,'" + Context.tempValues.get("productName") + "')])")));
		browserFactory.getWait()
				.until(ExpectedConditions.attributeContains(
						By.xpath("(//button[contains(@aria-label,'" +Context.tempValues.get("productName") + "')])"),
						"aria-label", Context.tempValues.get("productName")));
		((JavascriptExecutor) browserFactory.getDriver()).executeScript("arguments[0].click();",
				browserFactory.getDriver().findElement(By
						.xpath("(//button[contains(@aria-label,'" + Context.tempValues.get("productName") + "')])")));
		return this;
	}

	public ProductsMission searchProduct() throws Throwable {
		int temp = 1;
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Product_Search.xlsx");
		int product_Lookup_Menu = 1;
		int product_carousel = 1;
		int start_over = 1;
		int product_search_carousel = 1;
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i = i + 2) {
			int product_lookup = 1;
			System.out.println("Remaining Products to Test-->" + ((ExcelUtils.getLastRownNo("Sheet1") / 2) - i));
			for (int j = 1; j < ExcelUtils.getLastColumnNo("Sheet1", i); j++) {
				if (!(ExcelUtils.getCellData("Sheet1", i, j) == null
						|| ExcelUtils.getCellData("Sheet1", i, j).equals(""))) {
					try {
						browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(
								By.xpath("(//button[contains(@aria-label,'Lookup Product')])"), product_Lookup_Menu));
						product_Lookup_Menu++;
						commonPage.enterTxt("Product Lookup " + ExcelUtils.getCellData("Sheet1", i, j));
						String expectedProductName = ExcelUtils.getCellData("Sheet1", i, 0);

						try {
							browserFactory.getWait()
									.until(ExpectedConditions.numberOfElementsToBe(
											By.xpath("//div[contains(@class,'indented_content')]//p[.='Top Results']"),
											product_search_carousel));
							product_search_carousel++;
							browserFactory.getWait()
									.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
											By.xpath("(//div[contains(@class,'indented_content')])[last()]//button")))
									.stream()
									.filter(e -> e.getText().toLowerCase().equals(expectedProductName.toLowerCase()))
									.findFirst().get().click();
						} catch (Exception e) {
							e.printStackTrace();
							System.out.println("--->catch block 99");
							browserFactory.setWait(browserFactory.getDriver(), 10);
						}

						browserFactory.getWait()
								.until(ExpectedConditions.numberOfElementsToBe(
										By.xpath("//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='"
												+ expectedProductName.trim() + "']"),
										product_lookup));
						product_lookup++;
						ExcelUtils.setCellData("Sheet1", "PASS", i + 1, j, HSSFColor.GREEN.index);
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("-->Catch block 1");
						ExcelUtils.setCellData("Sheet1", "FAIL", i + 1, j, HSSFColor.RED.index);
						try {
							commonPage.enterTxt("cancel");
							commonPage.clickOption("Yes");
							browserFactory.getWait().until(ExpectedConditions
									.numberOfElementsToBe(By.xpath("//p[contains(.,'start over.')]"), start_over));
							start_over++;
						} catch (Exception e1) {
							System.out.println("-->Catch block 2");
							commonPage.enterTxt("Main Menu");
						}
					}

					try {
						if (temp == 1) {
							browserFactory.getWait()
									.until(ExpectedConditions
											.elementToBeClickable(By.xpath("//button//nobr[.='Onboarding Help']")))
									.isDisplayed();
							temp++;
						} else
							browserFactory.getWait()
									.until(ExpectedConditions
											.elementToBeClickable(By.xpath("//button//nobr[.='Feedback']")))
									.isDisplayed();
					} catch (Exception e) {
						System.out.println("-->Catch block 3");
					}
				}
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Product_Search.xlsx");
		return this;
	}

	public ProductsMission searchProductDirectly() throws Throwable {
		int temp = 1;
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Product_Lookup.xlsx");
		int product_search_carousel = 1;
		int product_detail_carousel = 1;
		int product_info_not_found = 1;
		int faq_info = 1;
		int start_over = 1;
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			int product_lookup = 1;
			int dosage_info = 1;
			int technical_info = 1;
			int ordering_info = 1;
			int specification_info = 1;
			int sds_info = 1;
			int verify_product_dosage_info = 1;
			int adjust_a_dispenser_info = 1;
			System.out.println("Remaining Products to Test-->" + ((ExcelUtils.getLastRownNo("Sheet1")) - i));
			for (int j = 1; j < ExcelUtils.getLastColumnNo("Sheet1", i); j++) {
				try {
					String expectedProductName = ExcelUtils.getCellData("Sheet1", i, 0);
					if (!ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>"))
						commonPage.enterTxt(
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", " "));
					else
						commonPage.enterTxt(ExcelUtils.getCellData("Sheet1", 0, j)
								.replaceAll("<partial product name>", expectedProductName.split(" ")[0])
								.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", " "));
					try {
						browserFactory.getWait()
								.until(ExpectedConditions.numberOfElementsToBe(
										By.xpath("//div[contains(@class,'indented_content')]//p[.='Top Results']"),
										product_search_carousel));
						product_search_carousel++;
						browserFactory.getWait()
								.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
										By.xpath("(//div[contains(@class,'indented_content')])[last()]//button")))
								.stream()
								.filter(e -> e.getText().toLowerCase().equals(expectedProductName.toLowerCase()))
								.findFirst().get().click();
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("--->catch block 99");
						browserFactory.setWait(browserFactory.getDriver(), 10);
					}

					if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("lookup".toLowerCase())) {
						browserFactory.getWait()
								.until(ExpectedConditions.numberOfElementsToBe(
										By.xpath("//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='"
												+ expectedProductName.trim() + "']"),
										product_lookup));
						product_lookup++;
					} else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Dosage".toLowerCase())) {
						try {
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By
									.xpath("//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='Dosage of "
											+ expectedProductName.trim() + "']"),
									dosage_info));
							dosage_info++;
						} catch (Exception e) {
							System.out.println("inner catch block Dosage-->");
							e.printStackTrace();
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'webchat__stacked')]//p[contains(.,'please visit our Ecolab Sales')]"),
									product_info_not_found));
							product_info_not_found++;
						}
					} else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("FAQ".toLowerCase())
							|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("ESS".toLowerCase())) {
						try {
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='Frequently Asked Questions - Document on ESS']"),
									faq_info));
							faq_info++;
						} catch (Exception e) {
							System.out.println("inner catch block FAQ-->");
							e.printStackTrace();
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'webchat__stacked')]//p[contains(.,'please visit our Ecolab Sales')]"),
									product_info_not_found));
							product_info_not_found++;
						}
					} else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase()
							.contains("Technical".toLowerCase())) {
						try {
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='Technical Information of "
											+ expectedProductName.trim() + "']"),
									technical_info));
							technical_info++;
						} catch (Exception e) {
							System.out.println("inner catch block Technical-->");
							e.printStackTrace();
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'webchat__stacked')]//p[contains(.,'please visit our Ecolab Sales')]"),
									product_info_not_found));
							product_info_not_found++;
						}
					} else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase()
							.contains("Ordering".toLowerCase())) {
						try {
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='Ordering information of "
											+ expectedProductName.trim() + "']"),
									ordering_info));
							ordering_info++;
						} catch (Exception e) {
							System.out.println("inner catch block Ordering-->");
							e.printStackTrace();
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'webchat__stacked')]//p[contains(.,'please visit our Ecolab Sales')]"),
									product_info_not_found));
							product_info_not_found++;
						}
					} else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase()
							.contains("Specification".toLowerCase())
							|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("PSD".toLowerCase())) {
						try {
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='Specification of "
											+ expectedProductName.trim() + "']"),
									specification_info));
							specification_info++;
						} catch (Exception e) {
							System.out.println("inner catch block Specification-->");
							e.printStackTrace();
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'webchat__stacked')]//p[contains(.,'please visit our Ecolab Sales')]"),
									product_info_not_found));
							product_info_not_found++;
						}
					} else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("SDS".toLowerCase())
							|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase()
									.contains("Safety Data Sheet".toLowerCase())) {
						try {
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='Safety Data Sheet of "
											+ expectedProductName.trim() + "']"),
									sds_info));
							sds_info++;
						} catch (Exception e) {
							System.out.println("inner catch block Safety Data Sheet-->");
							e.printStackTrace();
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'webchat__stacked')]//p[contains(.,'please visit our Ecolab Sales')]"),
									product_info_not_found));
							product_info_not_found++;
						}
					}

					else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Adjust".toLowerCase())) {
						try {
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='Adjust a Dispenser of "
											+ expectedProductName.trim() + "']"),
									adjust_a_dispenser_info));
							adjust_a_dispenser_info++;
						} catch (Exception e) {
							System.out.println("inner catch block Adjust-->");
							e.printStackTrace();
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'webchat__stacked')]//p[contains(.,'please visit our Ecolab Sales')]"),
									product_info_not_found));
							product_info_not_found++;
						}
					}

					else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Video".toLowerCase())) {
						try {
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'carousel_indented_content')]//li[1]//p[.='Verify Product Dosage of "
											+ expectedProductName.trim() + "']"),
									verify_product_dosage_info));
							verify_product_dosage_info++;
						} catch (Exception e) {
							System.out.println("inner catch block Adjust-->");
							e.printStackTrace();
							browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(By.xpath(
									"//div[contains(@class,'webchat__stacked')]//p[contains(.,'please visit our Ecolab Sales')]"),
									product_info_not_found));
							product_info_not_found++;
						}
					}

					ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("-->Catch block 1");
					ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
				}
				try {
					if (temp == 1) {
						browserFactory.getWait()
								.until(ExpectedConditions
										.elementToBeClickable(By.xpath("//button//nobr[.='Onboarding Help']")))
								.isDisplayed();
						temp++;
					} else
						browserFactory.getWait().until(
								ExpectedConditions.elementToBeClickable(By.xpath("//button//nobr[.='Feedback']")))
								.isDisplayed();
				} catch (Exception e) {
					try {
						System.out.println("-->Catch block 3");
						commonPage.enterTxt("cancel");
						commonPage.clickOption("Yes");
						browserFactory.getWait().until(ExpectedConditions
								.numberOfElementsToBe(By.xpath("//p[contains(.,'start over.')]"), start_over));
						start_over++;
					} catch (Exception e1) {

					}
				}
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Product_Lookup.xlsx");
		return this;
	}

	public ProductsMission verifyProductDataWithESS() throws Throwable {
		int temp = 1;
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/VerifyProductData.xlsx");
//		int product_Lookup_Menu = 1;
//		int what_specific_product = 1;
		int product_carousel = 1;
		int start_over = 1;
		String parentWindow = browserFactory.getDriver().getWindowHandle();
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			try {
//				browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(
//						By.xpath("(//button[contains(@aria-label,'Lookup Product')])"), product_Lookup_Menu));
//				commonPage.clickMenuOption("Lookup Product");
//				product_Lookup_Menu++;
//				browserFactory.getWait().until(ExpectedConditions.numberOfElementsToBe(
//						By.xpath("//p[contains(.,'What specific product')]"), what_specific_product));
//				commonPage.verifyMessageFromChatBot("What specific product");
//				what_specific_product++;
				commonPage.enterTxt("Find " + ExcelUtils.getCellData("Sheet1", i, 0).replaceAll("[^a-zA-Z0-9- ]", ""));
				String expectedProductName = ExcelUtils.getCellData("Sheet1", i, 0);
				try {
					browserFactory.getWait()
							.until(ExpectedConditions.numberOfElementsToBe(
									By.xpath("//div[contains(@class,'carousel_indented_content')]//p[.='Top Results']"),
									product_carousel));
					product_carousel++;
					browserFactory.getWait()
							.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
									By.xpath("(//div[contains(@class,'indented_content')])[last()]//button")))
							.stream().filter(e -> e.getText().toLowerCase().equals(expectedProductName.toLowerCase()))
							.findFirst().get().click();
				} catch (Exception e) {
					System.out.println("Product result came directly");
				}
				((JavascriptExecutor) browserFactory.getDriver()).executeScript("window.open(arguments[0])");
				browserFactory.getDriver().switchTo().window(parentWindow);
				for (String window : browserFactory.getDriver().getWindowHandles()) {
					if (!window.equals(parentWindow)) {
						System.out.println(window);
						browserFactory.getDriver().switchTo().window(window);
						break;
					}
				}
				browserFactory.getDriver().get(GetPropertiesData.getPropertyValue("ess"));
				essPage.enterTextInSearchBox(ExcelUtils.getCellData("Sheet1", i, 0)).clickOnProductTab()
						.clickOnProducts(ExcelUtils.getCellData("Sheet1", i, 0));//.setCountry();
				String productDescription = essPage.productDescription();
				List<String> TechnicalInfoLinks = essPage.getTechnicalInfoLinks();
				List<String> OrderingInfo = essPage.getOrderingInfo();
				List<String> SpecificationInfo = essPage.getSpecificationInfo();
				List<String> SDSLinks = essPage.getSDSLinks();
				Map<String, Boolean> FAQLinks = essPage.getFAQLinks();
				Map<String, Boolean> Video = essPage.getVideoLinks();
				browserFactory.getDriver().close();
				browserFactory.getDriver().switchTo().window(parentWindow);
				try {
					browserFactory.getWait().until(ExpectedConditions.visibilityOfElementLocated(
							By.xpath("//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
									+ expectedProductName + "']//.//..//..//..//..//..//..//..//..//p[contains(.,'"
									+ productDescription + "')]")))
							.isDisplayed();
					ExcelUtils.setCellData("Sheet1", "PASS", i, 1, HSSFColor.GREEN.index);
				} catch (Exception e) {
					System.out.println("Product Description Mismatch-->");
					e.printStackTrace();
					ExcelUtils.setCellData("Sheet1", "FAIL", i, 1, HSSFColor.RED.index);
				}
				if (TechnicalInfoLinks.size() > 0) {
					try {
						TechnicalInfoLinks.stream().allMatch(e -> browserFactory.getWait()
								.until(ExpectedConditions.visibilityOfElementLocated(
										By.xpath("//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
												+ expectedProductName
												+ "']//.//..//..//..//..//..//..//..//..//button[.='" + e + "']")))
								.isDisplayed());
						ExcelUtils.setCellData("Sheet1", "PASS", i, 3, HSSFColor.GREEN.index);
					} catch (Exception e) {
						System.out.println("TechnicalInfoLinks Mismatch-->");
						e.printStackTrace();
						ExcelUtils.setCellData("Sheet1", "FAIL", i, 3, HSSFColor.RED.index);
					}
				} else {
					ExcelUtils.setCellData("Sheet1", "PASS", i, 3, HSSFColor.GREEN.index);
				}
				if (OrderingInfo.size() > 0) {
					try {
						OrderingInfo.stream().allMatch(e -> browserFactory.getWait()
								.until(ExpectedConditions.visibilityOfElementLocated(
										By.xpath("//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
												+ expectedProductName + "']//.//..//..//..//..//..//..//..//..//p[.='"
												+ e + "']")))
								.isDisplayed());
						ExcelUtils.setCellData("Sheet1", "PASS", i, 2, HSSFColor.GREEN.index);
					} catch (Exception e) {
						System.out.println("OrderingInfoLinks Mismatch-->");
						e.printStackTrace();
						ExcelUtils.setCellData("Sheet1", "FAIL", i, 2, HSSFColor.RED.index);
					}
				} else {
					ExcelUtils.setCellData("Sheet1", "PASS", i, 2, HSSFColor.GREEN.index);
				}

				if (SpecificationInfo.size() > 0) {
					try {
						SpecificationInfo.stream().allMatch(e -> browserFactory.getWait()
								.until(ExpectedConditions.visibilityOfElementLocated(
										By.xpath("//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
												+ expectedProductName + "']//.//..//..//..//..//..//..//..//..//p[.='"
												+ e + "']")))
								.isDisplayed());
						ExcelUtils.setCellData("Sheet1", "PASS", i, 4, HSSFColor.GREEN.index);
					} catch (Exception e) {
						System.out.println("SpecificationInfoLinks Mismatch-->");
						e.printStackTrace();
						ExcelUtils.setCellData("Sheet1", "FAIL", i, 4, HSSFColor.RED.index);
					}
				} else {
					ExcelUtils.setCellData("Sheet1", "PASS", i, 4, HSSFColor.GREEN.index);
				}

				if (SDSLinks.size() > 0) {
					try {
						SDSLinks.stream().allMatch(e -> browserFactory.getWait()
								.until(ExpectedConditions.visibilityOfElementLocated(
										By.xpath("//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
												+ expectedProductName
												+ "']//.//..//..//..//..//..//..//..//..//button[.='" + e + "']")))
								.isDisplayed());
						ExcelUtils.setCellData("Sheet1", "PASS", i, 5, HSSFColor.GREEN.index);
					} catch (Exception e) {
						System.out.println("SpecificationInfoLinks Mismatch-->");
						e.printStackTrace();
						ExcelUtils.setCellData("Sheet1", "FAIL", i, 5, HSSFColor.RED.index);
					}
				} else {
					ExcelUtils.setCellData("Sheet1", "PASS", i, 5, HSSFColor.GREEN.index);
				}

				if (FAQLinks.size() > 0) {
					try {
						FAQLinks.entrySet().stream().forEach(e -> {
							if (e.getValue()) {
								Assert.assertTrue(browserFactory.getWait()
										.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
												"//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
														+ expectedProductName
														+ "']//.//..//..//..//..//..//..//..//..//button[.='"
														+ e.getKey() + "']")))
										.isDisplayed()
										&& browserFactory.getWait()
												.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
														"//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
																+ expectedProductName
																+ "']//..//..//..//..//..//../../..//p[contains(.,'Frequently Asked Questions')]//..//..//p[contains(.,'internal use')]")))
												.isDisplayed());
							} else {
								Assert.assertTrue(browserFactory.getWait()
										.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
												"//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
														+ expectedProductName
														+ "']//.//..//..//..//..//..//..//..//..//button[.='"
														+ e.getKey() + "']")))
										.isDisplayed());
							}
						});
						ExcelUtils.setCellData("Sheet1", "PASS", i, 6, HSSFColor.GREEN.index);
					} catch (Exception e) {
						System.out.println("FAQLinks Mismatch-->");
						e.printStackTrace();
						ExcelUtils.setCellData("Sheet1", "FAIL", i, 6, HSSFColor.RED.index);
					}
				} else {
					ExcelUtils.setCellData("Sheet1", "PASS", i, 6, HSSFColor.GREEN.index);
				}

				if (Video.size() > 0) {
					try {
						Video.entrySet().stream().forEach(e -> {
							if (e.getValue()) {
								Assert.assertTrue(browserFactory.getWait()
										.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
												"//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
														+ expectedProductName
														+ "']//.//..//..//..//..//..//..//..//..//button[.='"
														+ e.getKey() + "']")))
										.isDisplayed()
										&& browserFactory.getWait()
												.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
														"//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
																+ expectedProductName
																+ "']//..//..//..//..//..//../../..//p[contains(.,'Verify Product Dosage')]//..//..//p[contains(.,'internal use')]")))
												.isDisplayed());
							} else {
								Assert.assertTrue(browserFactory.getWait()
										.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
												"//div[contains(@class,'webchat__carousel_indented_content')]//p[.='"
														+ expectedProductName
														+ "']//.//..//..//..//..//..//..//..//..//button[.='"
														+ e.getKey() + "']")))
										.isDisplayed());
							}
						});
						ExcelUtils.setCellData("Sheet1", "PASS", i, 7, HSSFColor.GREEN.index);
					} catch (Exception e) {
						System.out.println("FAQLinks Mismatch-->");
						e.printStackTrace();
						ExcelUtils.setCellData("Sheet1", "FAIL", i, 7, HSSFColor.RED.index);
					}
				} else {
					ExcelUtils.setCellData("Sheet1", "PASS", i, 7, HSSFColor.GREEN.index);
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("-->Catch block 1");
				try {
					commonPage.enterTxt("cancel");
					commonPage.clickOption("Yes");
					browserFactory.getWait().until(ExpectedConditions
							.numberOfElementsToBe(By.xpath("//p[contains(.,'start over.')]"), start_over));
					start_over++;
					commonPage.enterTxt("Main Menu");
				} catch (Exception e1) {
					System.out.println("-->Catch block 2");
				}
			}

			try {
				if (temp == 1) {
					browserFactory.getWait()
							.until(ExpectedConditions
									.elementToBeClickable(By.xpath("//button//nobr[.='Onboarding Help']")))
							.isDisplayed();
					temp++;
				} else
					browserFactory.getWait()
							.until(ExpectedConditions.elementToBeClickable(By.xpath("//button//nobr[.='Feedback']")))
							.isDisplayed();
			} catch (Exception e) {
				System.out.println("-->Catch block 3");
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/VerifyProductData.xlsx");
		return this;
	}

	public ProductsMission setCountry(String country) {
		commonPage.enterText("Select Preference");
		commonPage.verifyMessageFromChatBot("Would you like to");
		commonPage.clickOption("Yes");
		commonPage.clickOption(country);
		commonPage.verifyMessageFromChatBot("been set sucessfully");
		Context.tempValues.put("Country", country);
		return this;
	}
}
