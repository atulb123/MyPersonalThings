package com.test.missions;

import org.apache.poi.hssf.util.HSSFColor;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.test.pages.CommonPage;
import com.test.utility.ExcelUtils;
import com.test.utility.ProductAPICalls;

public class ProductAPIMissions {
	CommonPage commonPage = new CommonPage();

	public ProductAPIMissions validateProductUttrancesThroughAPI(String env) throws Throwable {
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Product_Lookup.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			System.out.println("Remaining Products to Test-->" + ((ExcelUtils.getLastRownNo("Sheet1")) - i));
			for (int j = 1; j < ExcelUtils.getLastColumnNo("Sheet1", i); j++) {
				String expectedProductName = ExcelUtils.getCellData("Sheet1", i, 0);
				if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Dosage".toLowerCase())
						&& (!ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("verify".toLowerCase()))) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
					//	if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "")
									.replaceAll("[\\s]{2,}", " "), "Dosage of " + expectedProductName.trim(),
									expectedProductName))//, "Find dosage of "
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
						//}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "")
										.replaceAll("[\\s]{2,}", " "),
								"Dosage of " + expectedProductName.trim()))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("FAQ".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("ESS".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase()
								.contains("frequently asked question".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("switch".toLowerCase())) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
						//if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
											" "),
									"Frequently Asked Questions - Document on ESS", expectedProductName))//, "Find FAQ of "
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
						//}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "")
										.replaceAll("[\\s]{2,}", " "),
										"Frequently Asked Questions - Document on ESS"))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Technical".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("tech info".toLowerCase())) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
					//	if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
											" "),
									"Technical Information of " + expectedProductName.trim(), expectedProductName
									))//"Find technical of "
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					//	}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
												" "),
								"Technical Information of " + expectedProductName.trim()))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Ordering".toLowerCase())) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
						//if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
											" "),
									"Ordering information of " + expectedProductName.trim(), expectedProductName
									))//"Find ordering of "
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
						//}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
												" "),
								"Ordering information of " + expectedProductName.trim()))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Specification".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("PSD".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("spec sheet".toLowerCase())) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
						//if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "")
									.replaceAll("[\\s]{2,}", " "), "Specification of " + expectedProductName.trim(),
									expectedProductName))//, "Find specification of "
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
						//}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
												" "),
								"Specification of " + expectedProductName.trim()))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("SDS".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase()
								.contains("Safety Data Sheet".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Safety Sheet".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Safety data".toLowerCase())) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
					//	if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "")
									.replaceAll("[\\s]{2,}", " "), "Safety Data Sheet of " + expectedProductName.trim(),
									expectedProductName ))//"Find safety data sheet of "
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					//	}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
												" "),
								"Safety Data Sheet of " + expectedProductName.trim()))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Adjust".toLowerCase())) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
						//if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
											" "),
									"Adjust a Dispenser of " + expectedProductName.trim(), expectedProductName
									))//"Find adjust dispenser of "
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
						//}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
												" "),
								"Adjust a Dispenser of " + expectedProductName.trim()))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}
				}

				else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("Video".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("verify".toLowerCase())) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
						//if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
											" "),
									"Verify Product Dosage of " + expectedProductName.trim(), expectedProductName
									))//"Find verify dosage of "
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
						//}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}",
												" "),
								"Verify Product Dosage of " + expectedProductName.trim()))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}
				} else if (ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("lookup <".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("find <".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("get <".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("product <".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase()
								.contains("lookup product for <".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase().contains("look up <".toLowerCase())
						|| ExcelUtils.getCellData("Sheet1", 0, j).toLowerCase()
								.contains("find product information".toLowerCase())) {
					if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
						//if (!getPartialProductName(expectedProductName).equals(expectedProductName)) {
							if (ProductAPICalls.checkProductUttrancesForPartialProduct(env, ExcelUtils
									.getCellData("Sheet1", 0, j)
									.replaceAll("<partial product name>", getPartialProductName(expectedProductName))
									.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "")
									.replaceAll("[\\s]{2,}", " "), expectedProductName, expectedProductName))
								ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
							//"Find "
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
						//}
					} else {
						if (ProductAPICalls.checkProductUttrancesForProduct(env,
								ExcelUtils.getCellData("Sheet1", 0, j).replaceAll("<product name>", expectedProductName)
										.replaceAll("[-]", " ").replaceAll("[^a-zA-z0-9 ]", "")
										.replaceAll("[\\s]{2,}", " "),
								expectedProductName))
							ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
					}

				}
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Product_Lookup.xlsx");
		return this;
	}

	public String getPartialProductName(String productName) {
		String[] temp = productName.split(" ");
		String partialProductName = "";
		if (temp.length == 1)
			return productName;
		else if (temp.length <= 3) {
			for (int i = 0; i < temp.length-1; i++) {
				partialProductName = partialProductName + temp[i];
				partialProductName = partialProductName + " ";
			}
			return partialProductName.trim();
		} else {
			for (int i = 0; i < temp.length - 2; i++) {
				partialProductName = partialProductName + temp[i];
				partialProductName = partialProductName + " ";
			}
			return partialProductName.trim();
		}
	}

	public ProductAPIMissions validateErrorMessageThroughAPI(String env, String errorMessage) throws Throwable {
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Error_Msg.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
			System.out.println("Remaining Products to Test-->" + ((ExcelUtils.getLastRownNo("Sheet1")) - i));
			for (int j = 1; j < ExcelUtils.getLastColumnNo("Sheet1", i); j++) {
				String expectedProductName = ExcelUtils.getCellData("Sheet1", i, 0).replaceAll("[-]", " ")
						.replaceAll("[^a-zA-z0-9 ]", "").replaceAll("[\\s]{2,}", " ");
				if (ExcelUtils.getCellData("Sheet1", 0, j).contains("<partial product name>")) {
					if (ProductAPICalls.checkErrorMessageDisplayed(env, getPartialProductName(expectedProductName),
							errorMessage))
						ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
					else
						ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
				} else {
					if (ProductAPICalls.checkErrorMessageDisplayed(env, expectedProductName, errorMessage))
						ExcelUtils.setCellData("Sheet1", "PASS", i, j, HSSFColor.GREEN.index);
					else
						ExcelUtils.setCellData("Sheet1", "FAIL", i, j, HSSFColor.RED.index);
				}
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Error_Msg.xlsx");
		return this;
	}
}
