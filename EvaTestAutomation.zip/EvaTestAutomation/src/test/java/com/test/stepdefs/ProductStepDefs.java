package com.test.stepdefs;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.test.baseclass.BaseClass;
import com.test.common.ComonActions;
import com.test.context.Context;
import com.test.missions.ProductAPIMissions;
import com.test.missions.ProductAPIParallelMissions;
import com.test.missions.ProductsMission;
import com.test.model.UserDataModel;
import com.test.pages.CommonPage;
import com.test.pages.ProductsPage;
import com.test.utility.GetUserData;
import com.test.utility.ProductAPICalls;
import com.test.utility.ProductAPIParallelCalls;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ProductStepDefs extends BaseClass {
	private CommonPage commonPage = new CommonPage();
	private ComonActions comonActions = new ComonActions();
	private GetUserData getUserData = new GetUserData();
	private ProductsMission productsMission = new ProductsMission();
	private ProductAPIMissions productAPIMissions = new ProductAPIMissions();
	private ProductAPIParallelMissions productAPIParallelMissions = new ProductAPIParallelMissions();

	@Then("I should see {string} info is displayed")
	public void i_should_see_info_is_displayed(String text) {
		Assert.assertTrue(browserFactory.getWait()
				.until(ExpectedConditions.attributeContains(By.xpath(
						"(//div[@class='webchat__row message']//*[contains(@aria-label,'" + text + "')])[last()]"),
						"aria-label", text)),
				"Information about product not displayed");
	}

	@Given("I choose {string} option displayed in menu section")
	public void i_choose_option_displayed_in_menu_section(String text) {
		commonPage.clickButton(text);
	}

	@Then("I should see menu options related to Product Wash Formula displayed")
	public void i_should_see_menu_options_related_to_Product_Wash_Formula_displayed(DataTable dataTable) {
		Assert.assertTrue(dataTable.asList().stream()
				.allMatch(text -> browserFactory.getWait().until(ExpectedConditions.attributeContains(
						By.xpath("(//button[contains(@aria-label,'" + text + "')])[last()]"), "aria-label", text))),
				"Wash Formula Menu not displayed");
	}

	@When("I Enter {string} as input")
	public void i_Enter_as_input(String text) {
		commonPage.enterMenuOption(text);
	}

	@Given("I login to EVA Appication as {string}")
	public void i_login_to_EVA_Appication_as(String userType) {
		UserDataModel userData = getUserData.getTestData(userType);
		comonActions.performLogin(userData.getUserName(), userData.getPassword());
	}

	@Then("I should see Techincal Information related to Laundry detergent plus product displayed when I choose below menu options")
	public void i_should_see_Techincal_Information_related_to_Laundry_detergent_plus_product_displayed_when_I_choose_below_menu_options(
			DataTable dataTable) {
		Assert.assertTrue(
				dataTable.asList().stream().allMatch(menus -> productsMission.verifyTechincalInformation(menus)),
				"Techincal Information related to Laundry detergent plus product is not displayed");
	}

	@When("I choose {string} option in menu section when displayed under menu section {string}")
	public void i_choose_option_in_menu_section_when_displayed_under_menu_section(String buttonText, String menuText) {
		commonPage.clickMenuButton(buttonText, menuText);
	}

	@Then("I should see Switchout Information related to Laundry detergent plus product displayed when I choose below menu options")
	public void i_should_see_Switchout_Information_related_to_Laundry_detergent_plus_product_displayed_when_I_choose_below_menu_options(
			DataTable dataTable) {
		Assert.assertTrue(
				dataTable.asList().stream().allMatch(menus -> productsMission.verifyTechincalInformation(menus)),
				"Switchout Information related to Laundry detergent plus product is not displayed");
	}

	@When("I choose below menu then corresponding product should be recommended")
	public void i_choose_below_menu_then_corresponding_product_should_be_recommended(DataTable table) {
		for (int i = 0; i < table.asLists().size(); i++) {
			if (i != 0)
				commonPage.clickOption("Product Recommendation");
			commonPage.clickOption(table.asLists().get(i).get(0));
			commonPage.clickOption(table.asLists().get(i).get(1));
			commonPage.clickOption(table.asLists().get(i).get(2));
			Assert.assertTrue(commonPage.verifyMessageFromChatBot(table.asLists().get(i).get(3)),
					"Failed to display the Product Recommendation");
		}
	}

	@When("I enter below menu then corresponding product should be recommended")
	public void i_enter_below_menu_then_corresponding_product_should_be_recommended(DataTable table) {
		for (int i = 0; i < table.asLists().size(); i++) {
			if (i != 0)
				commonPage.enterOption("Product Recommendation");
			commonPage.enterOption(table.asLists().get(i).get(0));
			commonPage.enterOption(table.asLists().get(i).get(1));
			commonPage.enterOption(table.asLists().get(i).get(2));
			Assert.assertTrue(commonPage.verifyMessageFromChatBot(table.asLists().get(i).get(3)),
					"Failed to display the Product Recommendation");
		}
	}

	@Then("I should see (Adjust a Dispenser|Verify Product Dosage) related to Laundry detergent plus product displayed when I choose below menu options")
	public void i_should_see_Adjust_a_Dispenser_related_to_Laundry_detergent_plus_product_displayed_when_I_choose_below_menu_options(
			DataTable dataTable) {
		for (int i = 0; i < dataTable.asLists().size(); i++) {
			commonPage.clickMenuOption(dataTable.asLists().get(i).get(0));
			Assert.assertTrue(commonPage.verifyTextBlockIsDisplayed(dataTable.asLists().get(i).get(1)),
					"Failed to display Adjust dispnser for " + dataTable.asLists().get(i).get(0));
		}
	}

	@When("I select first product from the list of products")
	public void i_select_first_product_from_the_list_of_products() {
		productsMission.selectFirstProductFromList(Context.tempValues.get("inputText"));
	}

	@Then("I should see prouduct list displayed")
	public void i_should_see_prouduct_list_displayed() {
		Assert.assertTrue(
				browserFactory.getWait()
						.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//div[contains(@class,'adaptiveCard')]//p[.='"
										+ Context.tempValues.get("productName") + "']")))
						.isDisplayed(),
				"Product Details Not Displayed");
	}

	@Then("Verify Product search is returning the right product")
	public void verify_Product_search_is_returning_the_right_product() throws Throwable {
		productsMission.searchProduct();
	}

	@Then("Verify Product search is returning the right product when product name is searched directly")
	public void verify_Product_search_is_returning_the_right_product_when_product_name_is_searched_directly()
			throws Throwable {
		productsMission.searchProductDirectly();
	}

	@Then("I should see product details when I enter {string}")
	public void i_should_see_product_details_when_I_enter(String productName) {
		commonPage.enterTxt(productName);
		Assert.assertTrue(
				browserFactory.getWait()
						.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//div[contains(@class,'adaptiveCard')]//p[.='"
										+ StringUtils.substringAfter(productName, "find ") + "']")))
						.isDisplayed(),
				"Product Details Not Displayed");
	}

	@Then("I should see product data matching with ESS website")
	public void i_should_see_product_data_matching_with_ESS_website() throws Throwable {
		productsMission.verifyProductDataWithESS();
	}

	@Given("Verify Product Uttrances through API request in {string} env")
	public void verify_Product_Uttrances_through_API_request_in_env(String env) throws Throwable {
		productAPIMissions.validateProductUttrancesThroughAPI(env);
	}

	@Given("I Enter partial product name as input {string}")
	public void i_Enter_partial_product_name_as_input(String productName) {
		commonPage.enterText(productName);
		Context.tempValues.put("inputText", productName.split(" ")[productName.split(" ").length - 1]);
	}

	@Given("Verify Error Message {string} when product name is entered directly in {string} env")
	public void verify_Error_Message_when_product_name_is_entered_directly_in_env(String errorMessage, String env)
			throws Throwable {
		productAPIMissions.validateErrorMessageThroughAPI(env, errorMessage);
	}

	@Given("Verify Product Uttrances through API request in {string} env with PARALLEL Executions")
	public void verify_Product_Uttrances_through_API_request_in_env_with_PARALLEL_Executions(String env)
			throws Throwable {
		productAPIParallelMissions.validateProductUttrancesParallelyThroughAPI(env);
	}

	@Then("{string} message should be displayed when invalid product {string} are given")
	public void message_should_be_displayed_when_invalid_product_are_given(String errorMessage, String input) {
		commonPage.enterText(input);
		Assert.assertTrue(browserFactory.getWait()
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//p[contains(.,'" + errorMessage + "')]")))
				.isDisplayed(), "Product Details Not Displayed");
	}

	@Given("I set the location as {string}")
	public void i_set_the_location_as(String country) {
		productsMission.setCountry(country);
	}
}
