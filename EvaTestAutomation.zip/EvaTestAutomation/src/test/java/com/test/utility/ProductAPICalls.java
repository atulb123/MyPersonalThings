package com.test.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.test.baseclass.BaseClass;
import com.test.context.Context;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ProductAPICalls extends BaseClass {
	public static Map<String, String> apiValues = new LinkedHashMap<String, String>();
	public final static String OAuth = Context.tempValues.get("OAuth");
	public static List<String> actualPartsDetails;
	public static Map<String, String> actualPartsImageStatus;
	public static Map<String, String> actual_model_name;
	public static Map<String, String> actual_assembly_name;

	public static void directLineTokenGenerator(String baseuri) {
		try {
			RestAssured.baseURI = GetPropertiesData.getPropertyValue(baseuri);
			JsonPath jp = new JsonPath(RestAssured.given().body("{\"userID\":\"d0bcf8ef-07d5-49bf-ba66-e3dc3a3c747a\"}")
					.contentType(ContentType.TEXT).when().post("/api/directline/token").then().extract().response()
					.asString());
			apiValues.put("userid", jp.get("userID").toString());
			apiValues.put("dltoken", jp.get("token.token").toString());
		} catch (Exception e) {
			System.out.println("Failed to generate DL Token");
		}
	}

	public static void conversationTokenGenerator() {
		try {
			RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
			JsonPath jp = new JsonPath(RestAssured.given().header("Authorization", "Bearer " + apiValues.get("dltoken"))
					.header("Accept", "application/json").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))").when()
					.post("/v3/directline/conversations").then().extract().response().asString());
			apiValues.put("conversationId", jp.get("conversationId").toString());
			apiValues.put("conversationToken", jp.get("token").toString());
		} catch (Exception e) {
			System.out.println("Failed to generate conversation Token");
		}
	}

	public static void activityEvent() {
		try {
			RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
			RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json")
					.body("{\"name\":\"oauth/signin\",\"type\":\"event\",\"channelData\":{\"oauthAccessToken\":\""
							+ OAuth
							+ "\",\"oauthProvider\":\"microsoft\"},\"channelId\":\"webchat\",\"from\":{\"id\":\""
							+ apiValues.get("userid")
							+ "\",\"name\":\"\",\"role\":\"user\"},\"locale\":\"en-US\",\"timestamp\":\"2020-01-20T19:23:58.484Z\",\"entities\":[{\"requiresBotState\":true,\"supportsListening\":true,\"supportsTts\":true,\"type\":\"ClientCapabilities\"}]}")
					.when().post("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then();
		} catch (Exception e) {
			System.out.println("Activity Event Failed");
		}
	}

	public static void selectAnyEvent(String testinput) {
		try {
			RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
			String body = "{\"text\":\"" + testinput
					+ "\",\"textFormat\":\"plain\",\"type\":\"message\",\"channelData\":{\"oauthAccessToken\":\""
					+ Context.tempValues.get("OAuth")
					+ "\",\"oauthProvider\":\"microsoft\"},\"channelId\":\"webchat\",\"from\":{\"id\":\""
					+ GetPropertiesData.getPropertyValue("userid")
					+ "\",\"name\":\"\",\"role\":\"user\"},\"locale\":\"en-US\"}";
			JsonPath jp = new JsonPath(
					RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
							.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
							.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
							.header("Content-Type", "application/json").body(body).when()
							.post("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
							.then().extract().response().asString());
			apiValues.put("watermarkid", Arrays.asList(jp.get("id").toString().split("[|]")).get(1));
		} catch (Exception e) {
			System.out.println("Failed to click on " + testinput);
		}
	}

	public static boolean verifyProductDetails(String validatetext) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		JsonPath jp = null;
		String tem;
		try {
			tem = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
			jp = new JsonPath(tem);
			// System.out.println("-->" + tem + "<--");
			return jp.get("activities[1].attachments[0].content.body[0].items[0].text").toString()
					.replaceAll("[^a-zA-Z0-9]", "").equalsIgnoreCase(validatetext.replaceAll("[^a-zA-Z0-9]", ""))
					&& Integer.parseInt(jp.get("activities[1].attachments.size()").toString()) == 10;
		} catch (Exception e) {
			try {
				return jp.get("activities[1].attachments[0].content.body[0].text").toString()
						.replaceAll("[^a-zA-Z0-9]", "").equalsIgnoreCase(validatetext.replaceAll("[^a-zA-Z0-9]", ""))
						&& Integer.parseInt(jp.get("activities[1].attachments.size()").toString()) == 10;
			} catch (Exception e1) {
				System.out.println("********product details not found*******");
				return false;
			}
		}
	}

	public static boolean verifyErrorMessage(String validatetext) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		JsonPath jp;
		try {
			String tem = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
			jp = new JsonPath(tem);
		} catch (Exception e) {
			return false;
		}
		try {
			if (jp.get("activities[0].text").toString().replaceAll("[^a-zA-Z0-9]", "")
					.contains(validatetext.replaceAll("[^a-zA-Z0-9]", "")))
				return true;
		} catch (Exception e) {
			System.out.println("Error Message Not Displayed");
			return false;
		}
		return false;
	}

	public static List<String> getListOfAssemblies(String modelname, String alternate_modelname) {
		List<String> actualAssemblyNames = new ArrayList<String>();
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		Response res = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid")).when()
				.get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities").then().extract()
				.response();
		try {
			if (!((res.jsonPath().getString("activities[0].attachments[0].content.title").toLowerCase()
					.replaceAll("[^a-zA-Z0-9]", "").contains(modelname.toLowerCase().replaceAll("[^a-zA-Z0-9]", "")))
					|| res.jsonPath().getString("activities[0].attachments[0].content.title").toLowerCase()
							.replaceAll("[^a-zA-Z0-9]", "")
							.contains(alternate_modelname.toLowerCase().replaceAll("[^a-zA-Z0-9]", ""))))
				return actualAssemblyNames;
			int attachmentsize = res.jsonPath().getInt("activities[0].attachments.size()");
			for (int i = 0; i < attachmentsize; i++) {
				for (int j = 0; j < res.jsonPath()
						.getInt("activities[0].attachments[" + i + "].content.buttons.size()"); j++) {
					actualAssemblyNames.add(res.jsonPath()
							.getString("activities[0].attachments[" + i + "].content.buttons[" + j + "].title").trim()
							.toLowerCase());
				}
			}
		} catch (Exception e) {
			System.out.println("Mismatch in Parts Payload-->" + res.asString() + "<--");
		}
		return actualAssemblyNames;
	}

	public static void getListOfParts() {
		actualPartsDetails = new ArrayList<String>();
		actualPartsImageStatus = new LinkedHashMap<String, String>();
		actual_model_name = new LinkedHashMap<String, String>();
		actual_assembly_name = new LinkedHashMap<String, String>();
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		Response res = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid")).when()
				.get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities").then().extract()
				.response();
		try {
			int attachmentsize = res.jsonPath().getInt("activities[0].attachments.size()");
			for (int i = 0; i < attachmentsize; i++) {
				actual_model_name.put(
						res.jsonPath()
								.getString("activities[0].attachments[" + i + "].content.actions[2].data.partNumber")
								.trim().toLowerCase(),
						res.jsonPath().getString("activities[0].attachments[" + i + "].content.actions[2].data.parentName").trim()
								.toLowerCase());
				actual_assembly_name.put(
						res.jsonPath()
								.getString("activities[0].attachments[" + i + "].content.actions[2].data.partNumber")
								.trim().toLowerCase(),
						res.jsonPath().getString("activities[0].attachments[" + i + "].content.actions[2].data.assemblyName").trim()
								.toLowerCase());
				actualPartsDetails.add(res.jsonPath()
						.getString("activities[0].attachments[" + i + "].content.actions[2].data.partName").trim()
						.toLowerCase());
				actualPartsDetails.add(res.jsonPath()
						.getString("activities[0].attachments[" + i + "].content.actions[2].data.partNumber").trim()
						.toLowerCase());
				if (res.jsonPath()
						.getString(
								"activities[0].attachments[" + i + "].content.body[0].items[2].columns[0].items[0].url")
						.trim().toLowerCase().contains("evachat"))
					actualPartsImageStatus.put(res.jsonPath()
							.getString("activities[0].attachments[" + i + "].content.actions[2].data.partNumber").trim()
							.toLowerCase(), "No");
				else
					actualPartsImageStatus.put(res.jsonPath()
							.getString("activities[0].attachments[" + i + "].content.actions[2].data.partNumber").trim()
							.toLowerCase(), "Yes");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Mismatch in Parts Payload-->" + res.asString() + "<--");
		}
	}

	public static void getListOfPartsByParentName() {
		actualPartsDetails = new ArrayList<String>();
		actual_model_name = new LinkedHashMap<String, String>();
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		Response res = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
				.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
				.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
				.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid")).when()
				.get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities").then().extract()
				.response();
		try {
			int attachmentsize = res.jsonPath().getInt("activities[0].attachments.size()");
			for (int i = 0; i < attachmentsize; i++) {
				actual_model_name.put(
						res.jsonPath()
								.getString("activities[0].attachments[" + i + "].content.actions[2].data.partNumber")
								.trim().toLowerCase(),
						res.jsonPath()
								.getString("activities[0].attachments[" + i + "].content.actions[2].data.parentName")
								.trim().toLowerCase());
				actualPartsDetails.add(res.jsonPath()
						.getString("activities[0].attachments[" + i + "].content.actions[2].data.partName").trim()
						.toLowerCase());
				actualPartsDetails.add(res.jsonPath()
						.getString("activities[0].attachments[" + i + "].content.actions[2].data.partNumber").trim()
						.toLowerCase());
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Mismatch in Parts Payload-->" + res.asString() + "<--");
		}
	}

	public static boolean verifyPartialProductDetails(String productName) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		JsonPath jp;
		try {
			System.out.println("--->1.1");
			String ee = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
			jp = new JsonPath(ee);
		} catch (Exception e) {
			System.out.println("*********");
			return false;
		}

		try {
			int attachmentsize = Integer.parseInt(jp.get("activities[1].attachments.size()").toString());
			for (int i = 0; i < attachmentsize; i++) {
				System.out.println("-->" + Integer
						.parseInt(jp.get("activities[1].attachments[" + i + "].content.buttons.size()").toString()));
				for (int j = 0; j < Integer.parseInt(
						jp.get("activities[1].attachments[" + i + "].content.buttons.size()").toString()); j++) {
					if (jp.get("activities[1].attachments[" + i + "].content.buttons[" + j + "].title").toString()
							.replaceAll("[^a-zA-Z0-9]", "")
							.equalsIgnoreCase(productName.replaceAll("[^a-zA-Z0-9]", ""))) {
						System.out.println("----->>>>"
								+ jp.get("activities[1].attachments[" + i + "].content.buttons[" + j + "].value")
										.toString());
						apiValues.put("productUtterance",
								jp.get("activities[1].attachments[" + i + "].content.buttons[" + j + "].value")
										.toString());
						return true;
					}
				}
			}
		} catch (Exception e2) {
			System.out.println("--->1.4");
			return false;
		}
		return false;
	}

	public static boolean verifyContentInResponse(String validatetext) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		String response = "";
		try {
			response = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
		} catch (Exception e) {
		}
		if (response.toLowerCase().replaceAll("[^a-zA-Z0-9:]", "")
				.contains(validatetext.toLowerCase().replaceAll("[^a-zA-Z0-9:]", "")))
			return true;
		else
			return false;
	}

	public static String getlistOfPartsAsResponse() {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		String response = "";
		try {
			response = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
		} catch (Exception e) {
		}
		return response.toLowerCase();
	}

	public static boolean verifyPartialModelName(String modelName, String alternate_model_name) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		JsonPath jp;
		try {
			System.out.println("--->1.1");
			String ee = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
			jp = new JsonPath(ee);
		} catch (Exception e) {
			System.out.println("*********");
			return false;
		}

		if (alternate_model_name.toLowerCase().contains("Dishmachine: ".toLowerCase()))
			alternate_model_name = StringUtils.substringAfter(alternate_model_name, "Dishmachine: ").trim();
		else if (alternate_model_name.toLowerCase().contains("Dispenser: ".toLowerCase()))
			alternate_model_name = StringUtils.substringAfter(alternate_model_name, "Dispenser: ").trim();

		try {
			int attachmentSize = Integer.parseInt(jp.get("activities[0].attachments.size()").toString());
			for (int j = 0; j < attachmentSize; j++) {
				int buttonSize = Integer
						.parseInt(jp.get("activities[0].attachments[" + j + "].content.buttons.size()").toString());
				for (int i = 0; i < buttonSize; i++) {
					if (modelName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase().equalsIgnoreCase(
							jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].title").toString()
									.replaceAll("[^a-zA-Z0-9]", "").toLowerCase())
							|| alternate_model_name.replaceAll("[^a-zA-Z0-9]", "").toLowerCase().equalsIgnoreCase(
									jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].title")
											.toString().replaceAll("[^a-zA-Z0-9]", "").toLowerCase())) {
						System.out.println("modelUtterance----->>>>"
								+ jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].value")
										.toString());
						apiValues.put("modelUtterance",
								jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].value")
										.toString());
						return true;
					}
				}
			}
		} catch (Exception e2) {
			System.out.println("--->1.4");
			return false;
		}
		return false;
	}

	public static boolean verifyButtonText(String modelName, String alternate_model_name) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		JsonPath jp;
		try {
			System.out.println("--->1.1");
			String ee = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
			jp = new JsonPath(ee);
		} catch (Exception e) {
			System.out.println("*********");
			return false;
		}
		if (alternate_model_name.toLowerCase().contains("Dishmachine: ".toLowerCase()))
			alternate_model_name = StringUtils.substringAfter(alternate_model_name, "Dishmachine: ").trim();
		else if (alternate_model_name.toLowerCase().contains("Dispenser: ".toLowerCase()))
			alternate_model_name = StringUtils.substringAfter(alternate_model_name, "Dispenser: ").trim();
		try {
			int attachmentSize = Integer.parseInt(jp.get("activities[0].attachments.size()").toString());
			for (int j = 0; j < attachmentSize; j++) {
				int buttonSize = Integer
						.parseInt(jp.get("activities[0].attachments[" + j + "].content.buttons.size()").toString());
				for (int i = 0; i < buttonSize; i++) {
					if (modelName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase().equalsIgnoreCase(
							jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].title").toString()
									.replaceAll("[^a-zA-Z0-9]", "").toLowerCase())
							|| alternate_model_name.replaceAll("[^a-zA-Z0-9]", "").toLowerCase().equalsIgnoreCase(
									jp.get("activities[0].attachments[" + j + "].content.buttons[" + i + "].title")
											.toString().replaceAll("[^a-zA-Z0-9]", "").toLowerCase())) {
						return true;
					}
				}
			}
		} catch (Exception e2) {
			System.out.println("--->1.4");
			return false;
		}
		return false;
	}

	public static boolean verifyPartSerachWithModelName(String model_name, String assembly_name, String part_number,
			String part_name, String image_status) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		JsonPath jp;
		try {
			System.out.println("--->1.1");
			String ee = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
			jp = new JsonPath(ee);
		} catch (Exception e) {
			System.out.println("*********");
			return false;
		}

		try {
			int attachmentSize = Integer.parseInt(jp.get("activities[0].attachments.size()").toString());
			System.out.println("attachmentSize-->" + attachmentSize);
			for (int i = 0; i < attachmentSize; i++) {
				if (image_status.equalsIgnoreCase("yes")) {
					if (jp.get("activities[0].attachments[" + i + "].content.actions[2].data.partNumber").toString()
							.replaceAll("[^a-zA-Z0-9]", "").equalsIgnoreCase(part_number.replaceAll("[^a-zA-Z0-9]", ""))
							&& jp.get("activities[0].attachments[" + i + "].content.actions[2].data.partName")
									.toString().replaceAll("[^a-zA-Z0-9]", "")
									.equalsIgnoreCase(part_name.replaceAll("[^a-zA-Z0-9]", ""))
							&& jp.get("activities[0].attachments[" + i + "].content.actions[2].data.parentName")
									.toString().replaceAll("[^a-zA-Z0-9]", "")
									.equalsIgnoreCase(model_name.replaceAll("[^a-zA-Z0-9]", ""))
							&& jp.get("activities[0].attachments[" + i + "].content.actions[2].data.assemblyName")
									.toString().replaceAll("[^a-zA-Z0-9]", "")
									.equalsIgnoreCase(assembly_name.replaceAll("[^a-zA-Z0-9]", ""))
							&& jp.get("activities[0].attachments[" + i + "].content.actions[2].data.partImage")
									.toString().replaceAll("[^a-zA-Z0-9]", "")
									.contains("ecolabequipmentcatalog".replaceAll("[^a-zA-Z0-9]", "")))
						return true;
				} else {
					if (jp.get("activities[0].attachments[" + i + "].content.actions[2].data.partNumber").toString()
							.replaceAll("[^a-zA-Z0-9]", "").equalsIgnoreCase(part_number.replaceAll("[^a-zA-Z0-9]", ""))
							&& jp.get("activities[0].attachments[" + i + "].content.actions[2].data.partName")
									.toString().replaceAll("[^a-zA-Z0-9]", "")
									.equalsIgnoreCase(part_name.replaceAll("[^a-zA-Z0-9]", ""))
							&& jp.get("activities[0].attachments[" + i + "].content.actions[2].data.parentName")
									.toString().replaceAll("[^a-zA-Z0-9]", "")
									.equalsIgnoreCase(model_name.replaceAll("[^a-zA-Z0-9]", ""))
							&& jp.get("activities[0].attachments[" + i + "].content.actions[2].data.assemblyName")
									.toString().replaceAll("[^a-zA-Z0-9]", "")
									.equalsIgnoreCase(assembly_name.replaceAll("[^a-zA-Z0-9]", "")))
						return true;
				}
			}
		} catch (Exception e2) {
			System.out.println("--->1.4");
			return false;
		}
		return false;
	}

	public static boolean verifyPartialAssemblyName(String assemblyName) {
		RestAssured.baseURI = GetPropertiesData.getPropertyValue("directlineurl");
		JsonPath jp;
		try {
			System.out.println("--->1.1");
			String ee = RestAssured.given().header("Authorization", "Bearer " + apiValues.get("conversationToken"))
					.header("Accept", "*/*").header("X-Requested-With", "XMLHttpRequest")
					.header("x-ms-bot-agent", "DirectLine/3.0 (directlinejs; WebChat/4.6.0 (Full))")
					.header("Content-Type", "application/json").queryParam("watermark", apiValues.get("watermarkid"))
					.when().get("/v3/directline/conversations/" + apiValues.get("conversationId") + "/activities")
					.then().extract().response().asString();
			jp = new JsonPath(ee);
		} catch (Exception e) {
			System.out.println("*********");
			return false;
		}

		try {
			int buttonSize = Integer.parseInt(jp.get("activities[0].attachments[0].content.buttons.size()").toString());
			System.out.println("buttonSize-->" + buttonSize);
			for (int i = 0; i < buttonSize; i++) {
				if (jp.get("activities[0].attachments[0].content.buttons[" + i + "].title").toString()
						.replaceAll("[^a-zA-Z0-9]", "").equalsIgnoreCase(assemblyName.replaceAll("[^a-zA-Z0-9]", ""))) {
					System.out.println("assemblyUtterance----->>>>"
							+ jp.get("activities[0].attachments[0].content.buttons[" + i + "].value").toString());
					apiValues.put("assemblyUtterance",
							jp.get("activities[0].attachments[0].content.buttons[" + i + "].value").toString());
					return true;
				}
			}
		} catch (Exception e2) {
			System.out.println("--->1.4");
			return false;
		}
		return false;
	}

	public static boolean checkProductUttrancesForProduct(String baseuri, String testinput, String validatetext) {
		System.out.println(baseuri + "--" + testinput + "--" + validatetext);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		return verifyProductDetails(validatetext);
	}

	public static boolean checkProductUttrancesForPartialProduct(String baseuri, String testinput, String validatetext,
			String productName) {
		// , String utteranceText
		System.out.println(baseuri + "--" + testinput + "--" + validatetext + "--" + productName);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		if (verifyProductDetails(validatetext))
			return true;
		else if (verifyPartialProductDetails(productName)) {
			// selectAnyEvent(utteranceText + productName);
			selectAnyEvent(apiValues.get("productUtterance"));
			return verifyProductDetails(validatetext);
		}
		return false;
	}

	public static boolean checkErrorMessageDisplayed(String baseuri, String testinput, String validatetext) {
		System.out.println(baseuri + "--" + testinput + "--" + validatetext);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		return verifyErrorMessage(validatetext);
	}

	public static List<String> getAssemblyNames(String baseuri, String modelname, String alternate_modelname,
			String testinput) {
		System.out.println(baseuri + "--" + testinput);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		return getListOfAssemblies(modelname, alternate_modelname);
	}

	public static void getPartNamesByParentName(String baseuri, String model_name, String alternate_model_name,
			String testinput) {
		System.out.println(baseuri + "--" + testinput);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		if (!verifyButtonText(model_name, alternate_model_name)) {
			System.out.println("INSIDE IF BLOCK---->");
			getListOfPartsByParentName();
		} else if (verifyPartialModelName(model_name, alternate_model_name)) {
			System.out.println("INSIDE ELSE IF BLOCK---->");
			selectAnyEvent(apiValues.get("modelUtterance"));
			getListOfPartsByParentName();
		}
	}

	public static void getPartNames(String baseuri, String model_name, String alternate_model_name,
			String assembly_name, String testinput) {
		System.out.println(baseuri + "--" + testinput);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		if (verifyContentInResponse("Add to My List")) {
			System.out.println("--->1st IF BLOCK");
			getListOfParts();
			return;
		}
		if (verifyButtonText(model_name, alternate_model_name)) {
			System.out.println("--->2nd IF BLOCK");
			verifyPartialModelName(model_name, alternate_model_name);
			selectAnyEvent(apiValues.get("modelUtterance"));
		}
		if (verifyContentInResponse("following assemblies")) {
			System.out.println("--->3rd IF BLOCK");
			verifyPartialAssemblyName(assembly_name);
			selectAnyEvent(apiValues.get("assemblyUtterance"));
		}
		System.out.println("--->4rd IF BLOCK");
		getListOfParts();
	}

	public static List<String> getAssemblyNamesForPartialSearch(String baseuri, String modelname,
			String alternate_modelname, String testinput) {
		System.out.println(baseuri + "--" + testinput);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		if (!verifyButtonText(modelname, alternate_modelname))
			return getListOfAssemblies(modelname, alternate_modelname);
		else if (verifyPartialModelName(modelname, alternate_modelname)) {
			selectAnyEvent(apiValues.get("modelUtterance"));
			return getListOfAssemblies(modelname, alternate_modelname);
		} else
			return new ArrayList<String>();
	}

	public static String getPartNamesForPartialSearch(String baseuri, String testinput) {
		System.out.println(baseuri + "--" + testinput);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		return getlistOfPartsAsResponse();
	}

	public static boolean getPartsDetailsWhenSeachedwithModelName(String baseuri, String modelname,
			String assembly_name, String part_number, String part_name, String image_status, String testinput,
			String alternate_modelname) {
		System.out.println(baseuri + "--" + testinput);
		directLineTokenGenerator(baseuri);
		conversationTokenGenerator();
		activityEvent();
		selectAnyEvent(testinput);
		if (verifyContentInResponse("Add to My List"))
			return verifyPartSerachWithModelName(modelname, assembly_name, part_number, part_name, image_status);
		else {
			verifyPartialModelName(modelname, alternate_modelname);
			selectAnyEvent(apiValues.get("modelUtterance"));
			return verifyPartSerachWithModelName(modelname, assembly_name, part_number, part_name, image_status);
		}
	}
}
