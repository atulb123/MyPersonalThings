package com.test.missions;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;

import com.test.utility.ExcelUtils;
import com.test.utility.ProductAPICalls;

public class PartsAPIMission {

	public PartsAPIMission verifyAssemblyDetails(String env) throws Throwable {
		int rowno = 1;
		ExcelUtils.setExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Assembly_Data.xlsx");
		for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i = rowno) {
			String model_Name = ExcelUtils.getCellData("Sheet1", i, 0);
			String alternate_model_Name = ExcelUtils.getCellData("Sheet1", i, 1);
			String input_text = ExcelUtils.getCellData("Sheet1", 0, 3).replaceAll("<model_name>",
					// ExcelUtils.getCellData("Sheet1", i, 0).replaceAll("-", "
					// ").replaceAll("[^a-zA-Z0-9 ]", ""));
					ExcelUtils.getCellData("Sheet1", i, 0).replaceAll("[^a-zA-Z0-9- ]", ""));
			System.out.println("model_Name-->" + model_Name);
			System.out.println("alternate_model_Name-->" + alternate_model_Name);
			System.out.println("input_text-->" + input_text);
			List<String> expected_assemblyNames = new ArrayList<String>();
			int jLoopSize = getStepSize(i);
			for (int j = i; j <= jLoopSize; j++)
				expected_assemblyNames.add(ExcelUtils.getCellData("Sheet1", j, 2).trim().toLowerCase());
			System.out.println("expected_assemblyNames-->" + expected_assemblyNames);
			List<String> actual_assemblyNames = ProductAPICalls.getAssemblyNames(env, model_Name, alternate_model_Name,
					input_text);
			System.out.println("actual_assemblyNames-->" + actual_assemblyNames);
			ExcelUtils.setCellData("Sheet1", input_text, rowno, 3);
			if (actual_assemblyNames.size() != 0) {
				for (int j = 0; j < expected_assemblyNames.size(); j++) {
					if (actual_assemblyNames.contains(expected_assemblyNames.get(j)))
						ExcelUtils.setCellData("Sheet1", "PASS", rowno, 4, HSSFColor.GREEN.index);
					else
						ExcelUtils.setCellData("Sheet1", "FAIL", rowno, 4, HSSFColor.RED.index);
					rowno++;
				}
			} else {
				for (int j = 0; j < expected_assemblyNames.size(); j++) {
					ExcelUtils.setCellData("Sheet1", "Incorrect / Parts Details Not Displayed", rowno, 4,
							HSSFColor.RED.index);
					rowno++;
				}
			}
		}
		ExcelUtils.closeExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Assembly_Data.xlsx");
		return this;
	}

	public int getStepSize(int currentRowNo) throws Exception {
		int flag = 0;
		while (flag != 2 && currentRowNo != ExcelUtils.getLastRownNo("Sheet1") + 2) {
			if (!ExcelUtils.getCellData("Sheet1", currentRowNo, 0).equals(""))
				flag++;
			currentRowNo++;
		}
		int temp = currentRowNo - 2;
		System.out.println("Step SIze-->" + temp);
		return temp;
	}

	public PartsAPIMission verifyPartsDetails(String env) throws Throwable {
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Parts_Data.xlsx");
		for (int ul = 6; ul < ExcelUtils.getLastColumnNo("Sheet1", 0); ul = ul + 6) {
			int rowno = 1;
			for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i = rowno) {
				String model_Name = ExcelUtils.getCellData("Sheet1", i, 0);
				String alternate_model_Name = ExcelUtils.getCellData("Sheet1", i, 1);
				String assembly_name = ExcelUtils.getCellData("Sheet1", i, 2);
				String input_text = "";
				if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_assembly_name>")
						&& ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<partial_assembly_name>",
									getPartialName(ExcelUtils.getCellData("Sheet1", i, 2)))
							.replaceAll("<partial_model_name>",
									getPartialModelName(ExcelUtils.getCellData("Sheet1", i, 0)))
							.replaceAll("[-]", " ").replaceAll("[^a-zA-Z0-9 ]", "");
				else if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_assembly_name>")
						&& ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<partial_assembly_name>",
									getPartialName(ExcelUtils.getCellData("Sheet1", i, 2)))
							.replaceAll("<model_name>", ExcelUtils.getCellData("Sheet1", i, 0)).replaceAll("[-]", " ")
							.replaceAll("[^a-zA-Z0-9 ]", "");
				else if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<assembly_name>")
						&& ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<assembly_name>", ExcelUtils.getCellData("Sheet1", i, 2))
							.replaceAll("<partial_model_name>",
									getPartialModelName(ExcelUtils.getCellData("Sheet1", i, 0)))
							.replaceAll("[-]", " ").replaceAll("[^a-zA-Z0-9 ]", "");
				else
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<assembly_name>", ExcelUtils.getCellData("Sheet1", i, 2))
							.replaceAll("<model_name>", ExcelUtils.getCellData("Sheet1", i, 0)).replaceAll("[-]", " ")
							.replaceAll("[^a-zA-Z0-9 ]", "");
				System.out.println("input_text-->" + input_text);
				List<String> expected_partnames = new ArrayList<String>();
				List<String> expected_partnumbers = new ArrayList<String>();
				Map<String, String> expected_model_name = new LinkedHashMap<String, String>();
				Map<String, String> expected_alternate_model_name = new LinkedHashMap<String, String>();
				Map<String, String> expected_assembly_name = new LinkedHashMap<String, String>();
				Map<String, String> expected_image_status = new LinkedHashMap<String, String>();
				int jLoopSize = getStepSizeforParts(i, 2);
				for (int j = i; j <= jLoopSize; j++) {
					expected_partnumbers.add(ExcelUtils.getCellData("Sheet1", j, 3).trim().toLowerCase());
					expected_model_name.put(ExcelUtils.getCellData("Sheet1", j, 3).trim().toLowerCase(),
							ExcelUtils.getCellData("Sheet1", j, 0).trim().toLowerCase());
					expected_alternate_model_name.put(ExcelUtils.getCellData("Sheet1", j, 3).trim().toLowerCase(),
							ExcelUtils.getCellData("Sheet1", j, 1).trim().toLowerCase());
					expected_assembly_name.put(ExcelUtils.getCellData("Sheet1", j, 3).trim().toLowerCase(),
							ExcelUtils.getCellData("Sheet1", j, 2).trim().toLowerCase());
					expected_partnames.add(ExcelUtils.getCellData("Sheet1", j, 4).trim().toLowerCase());
					expected_image_status.put(ExcelUtils.getCellData("Sheet1", j, 3).trim().toLowerCase(),
							ExcelUtils.getCellData("Sheet1", j, 5).trim().toLowerCase());
				}
				System.out.println("expected_partnumbers-->" + expected_partnumbers);
				System.out.println("expected_partnames-->" + expected_partnames);
				System.out.println("expected_model_name-->" + expected_model_name);
				System.out.println("expected_alternate_model_name-->" + expected_alternate_model_name);
				System.out.println("expected_assembly_name-->" + expected_assembly_name);
				System.out.println("expected_image_status-->" + expected_image_status);
				ProductAPICalls.getPartNames(env, ExcelUtils.getCellData("Sheet1", i, 0),
						ExcelUtils.getCellData("Sheet1", i, 1), ExcelUtils.getCellData("Sheet1", i, 2), input_text);
				System.out.println("actualPartsDetails-->" + ProductAPICalls.actualPartsDetails);
				System.out.println("actual_model_name-->" + ProductAPICalls.actual_model_name);
				System.out.println("actual_assembly_name-->" + ProductAPICalls.actual_assembly_name);
				System.out.println("actualPartsImageStatus-->" + ProductAPICalls.actualPartsImageStatus);
				if (ProductAPICalls.actualPartsDetails.size() != 0) {
					for (int j = 0; j < expected_partnames.size(); j++) {
						ExcelUtils.setCellData("Sheet1", input_text, rowno, ul);
						try {
							if (ProductAPICalls.actual_model_name.get(expected_partnumbers.get(j))
									.contains(expected_model_name.get(expected_partnumbers.get(j)))
									|| ProductAPICalls.actual_model_name.get(expected_partnumbers.get(j))
											.contains(expected_alternate_model_name.get(expected_partnumbers.get(j))))
								ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 1, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 1, HSSFColor.RED.index);
							if (ProductAPICalls.actual_assembly_name.get(expected_partnumbers.get(j))
									.contains(expected_assembly_name.get(expected_partnumbers.get(j))))
								ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 2, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 2, HSSFColor.RED.index);
							if (expected_image_status.get(expected_partnumbers.get(j)).equalsIgnoreCase(
									ProductAPICalls.actualPartsImageStatus.get(expected_partnumbers.get(j))))
								ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 5, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 5, HSSFColor.RED.index);
							if (ProductAPICalls.actualPartsDetails.contains(expected_partnames.get(j)))
								ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 3, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 3, HSSFColor.RED.index);
							if (ProductAPICalls.actualPartsDetails.contains(expected_partnumbers.get(j)))
								ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 4, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 4, HSSFColor.RED.index);
						} catch (Exception e) {
							for (int k = ul + 1; k <= ul + 5; k++) {
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, k, HSSFColor.RED.index);
							}
						}
						rowno++;
					}
				} else {
					for (int j = 0; j < expected_partnames.size(); j++) {
						ExcelUtils.setCellData("Sheet1", input_text, rowno, ul);
						ExcelUtils.setCellData("Sheet1", "Parts Data Not Displayed", rowno, ul + 1,
								HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "Parts Data Not Displayed", rowno, ul + 2,
								HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "Parts Data Not Displayed", rowno, ul + 3,
								HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "Parts Data Not Displayed", rowno, ul + 4,
								HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "Parts Data Not Displayed", rowno, ul + 5,
								HSSFColor.RED.index);
						rowno++;
					}
				}
			}
		}
		ExcelUtils
				.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Parts_Data.xlsx");
		return this;
	}

	public int getStepSizeforParts(int currentRowNo, int colno) throws Exception {
		while (ExcelUtils.getCellData("Sheet1", currentRowNo, colno)
				.equals(ExcelUtils.getCellData("Sheet1", currentRowNo + 1, colno))
				&& ExcelUtils.getCellData("Sheet1", currentRowNo, 0)
						.equals(ExcelUtils.getCellData("Sheet1", currentRowNo + 1, 0)))
			currentRowNo++;
		System.out.println("Step SIze for parts-->" + currentRowNo);
		return currentRowNo;
	}

	public PartsAPIMission verifyAssemblyDetailsWhenPartialNameIsGiven(String env) throws Throwable {
		ExcelUtils.setExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Assembly_Data.xlsx");
		for (int k = 3; k < ExcelUtils.getLastColumnNo("Sheet1", 0); k = k + 2) {
			int rowno = 1;
			for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i = rowno) {
				String model_Name = ExcelUtils.getCellData("Sheet1", i, 0);
				String alternate_model_Name = ExcelUtils.getCellData("Sheet1", i, 1);
				String input_text = "";
				if (ExcelUtils.getCellData("Sheet1", 0, k).toLowerCase().contains("partial"))
					input_text = ExcelUtils.getCellData("Sheet1", 0, k).replaceAll("<partial_model_name>",
							getPartialName(ExcelUtils.getCellData("Sheet1", i, 0)));
				else if (ExcelUtils.getCellData("Sheet1", 0, k).toLowerCase().contains("incorrect"))
					input_text = ExcelUtils.getCellData("Sheet1", 0, k).replaceAll("<incorrect_model_name>",
							getIncorrectName(ExcelUtils.getCellData("Sheet1", i, 0)));
				else
					input_text = ExcelUtils.getCellData("Sheet1", 0, k).replaceAll("<model_name>", ExcelUtils
							.getCellData("Sheet1", i, 0).replaceAll("-", " ").replaceAll("[^a-zA-Z0-9 ]", ""));
				System.out.println("model_Name-->" + model_Name);
				System.out.println("alternate_model_Name-->" + alternate_model_Name);
				System.out.println("input_text-->" + input_text);
				List<String> expected_assemblyNames = new ArrayList<String>();
				int jLoopSize = getStepSize(i);
				for (int j = i; j <= jLoopSize; j++)
					expected_assemblyNames.add(ExcelUtils.getCellData("Sheet1", j, 2).trim().toLowerCase());
				System.out.println("expected_assemblyNames-->" + expected_assemblyNames);
				List<String> actual_assemblyNames = ProductAPICalls.getAssemblyNamesForPartialSearch(env, model_Name,
						alternate_model_Name, input_text);
				System.out.println("actual_assemblyNames-->" + actual_assemblyNames);
				ExcelUtils.setCellData("Sheet1", input_text, rowno, k);
				if (actual_assemblyNames.size() != 0) {
					for (int j = 0; j < expected_assemblyNames.size(); j++) {
						if (actual_assemblyNames.contains(expected_assemblyNames.get(j)))
							ExcelUtils.setCellData("Sheet1", "PASS", rowno, k + 1, HSSFColor.GREEN.index);
						else
							ExcelUtils.setCellData("Sheet1", "FAIL", rowno, k + 1, HSSFColor.RED.index);
						rowno++;
					}
				} else {
					for (int j = 0; j < expected_assemblyNames.size(); j++) {
						ExcelUtils.setCellData("Sheet1", "Incorrect / Assembly Details Not Displayed", rowno, k + 1,
								HSSFColor.RED.index);
						rowno++;
					}
				}
			}
		}
		ExcelUtils.closeExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Verify_Assembly_Data.xlsx");
		return this;
	}

	public String getPartialName(String partName) {
		partName = partName.replaceAll("-", " ").replaceAll("[^a-zA-z0-9 ]", "");
		String[] temp = partName.split(" ");
		if (temp.length <= 2)
			return partName;
		else
			return temp[0] + " " + temp[1]+ " " + temp[2];
	}

	public String getPartialModelName(String partName) {
		partName = partName.replaceAll("-", " ").replaceAll("[^a-zA-z0-9 ]", "");
		String[] temp = partName.split(" ");
		if (temp.length <= 2)
			return partName;
		else
			return temp[0] + " " + temp[1]+ " " + temp[2];
	}

	public String getPartialPartName(String partName) {
		partName = partName.replaceAll("-", " ").replaceAll("[^a-zA-z0-9 ]", "");
		String[] temp = partName.split(" ");
		if (temp.length <= 1)
			return partName;
		else
			return temp[0];
	}

	public String getIncorrectName(String partName) {
		partName = partName.replaceAll("-", " ").replaceAll("[^a-zA-z0-9 ]", "");
		String incorrect_part_name = "";
		String[] temp = partName.split(" ");
		if (temp.length == 1) {
			for (int i = 0; i < temp[0].length(); i++) {
				if (i == (int) ((temp[0].length()) / 2))
					incorrect_part_name = incorrect_part_name + (char) ((int) temp[0].charAt(i) + 2);
				else
					incorrect_part_name = incorrect_part_name + temp[0].charAt(i);
			}
		} else {
			for (int i = 0; i < 2; i++) {
				for (int j = 0; j < temp[i].length(); j++) {
					if (i == (int) ((temp[0].length()) / 2))
						incorrect_part_name = incorrect_part_name + (char) ((int) temp[i].charAt(j) + 2);
					else
						incorrect_part_name = incorrect_part_name + temp[i].charAt(j);
				}
				incorrect_part_name = incorrect_part_name + " ";
			}
		}
		return incorrect_part_name;
	}

	public PartsAPIMission verifyPartsDetailsWhenPartialNameIsGiven(String env) throws Throwable {
		ExcelUtils.setExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		for (int ul = 4; ul < ExcelUtils.getLastColumnNo("Sheet1", 0); ul = ul + 5) {
			int rowno = 1;
			for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i = rowno) {
				String input_text = "";
				if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_part_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<partial_part_name>",
									getPartialPartName(ExcelUtils.getCellData("Sheet1", i, 3)))
							.replaceAll("[-]", " ").replaceAll("[^a-zA-Z0-9 ]", "");
				else if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<part_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<part_name>", ExcelUtils.getCellData("Sheet1", i, 3)).replaceAll("[-]", " ")
							.replaceAll("[^a-zA-Z0-9 ]", "");
				else if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<part_number>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<part_number>", ExcelUtils.getCellData("Sheet1", i, 0)).replaceAll("[-]", " ")
							.replaceAll("[^a-zA-Z0-9 ]", "");
				System.out.println("input_text-->" + input_text);
				List<String> expected_partnames = new ArrayList<String>();
				List<String> expected_partnumbers = new ArrayList<String>();
				List<String> expected_model_name = new ArrayList<String>();
				List<String> expected_assembly_name = new ArrayList<String>();

				int jLoopSize = getStepSizeforParts(i, 0);
				for (int j = i; j <= jLoopSize; j++) {
					expected_partnumbers.add(ExcelUtils.getCellData("Sheet1", j, 0).trim().toLowerCase());
					expected_model_name.add(ExcelUtils.getCellData("Sheet1", j, 1).trim().toLowerCase());
					expected_assembly_name.add(ExcelUtils.getCellData("Sheet1", j, 2).trim().toLowerCase());
					expected_partnames.add(ExcelUtils.getCellData("Sheet1", j, 3).trim().toLowerCase());
				}
				System.out.println("expected_partnumbers-->" + expected_partnumbers);
				System.out.println("expected_partnames-->" + expected_partnames);
				System.out.println("expected_model_name-->" + expected_model_name);
				System.out.println("expected_assembly_name-->" + expected_assembly_name);
				String parts_response = ProductAPICalls.getPartNamesForPartialSearch(env, input_text);
				for (int j = 0; j < expected_partnames.size(); j++) {
					ExcelUtils.setCellData("Sheet1", input_text, rowno, ul);
					if (parts_response.contains(expected_partnames.get(j))
							&& parts_response.contains(expected_partnumbers.get(j))) {
						ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 1, HSSFColor.GREEN.index);
						ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 2, HSSFColor.GREEN.index);
						ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 3, HSSFColor.GREEN.index);
						ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 4, HSSFColor.GREEN.index);
					} else {
						ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 1, HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 2, HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 3, HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 4, HSSFColor.RED.index);
					}
					rowno++;
				}
			}
		}
		ExcelUtils.closeExcelFile(System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup.xlsx");
		return this;
	}

	public PartsAPIMission verifyPartsDetailsWhenSearchedWithModelName(String env) throws Throwable {
		ExcelUtils.setExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup_Model_Name.xlsx");
		for (int ul = 6; ul < ExcelUtils.getLastColumnNo("Sheet1", 0); ul = ul + 6) {
			for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i++) {
				String input_text = "";
				if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_part_name>")
						&& ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<partial_part_name>",
									getPartialPartName(ExcelUtils.getCellData("Sheet1", i, 4)))
							.replaceAll("<partial_model_name>", getPartialName(ExcelUtils.getCellData("Sheet1", i, 0)))
							.replaceAll("[-]", " ").replaceAll("[^a-zA-Z0-9 ]", "");
				else if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<part_name>")
						&& ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<part_name>", ExcelUtils.getCellData("Sheet1", i, 4))
							.replaceAll("<partial_model_name>", getPartialName(ExcelUtils.getCellData("Sheet1", i, 0)))
							.replaceAll("[-]", " ").replaceAll("[^a-zA-Z0-9 ]", "");
				else if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_part_name>")
						&& ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<partial_part_name>",
									getPartialPartName(ExcelUtils.getCellData("Sheet1", i, 4)))
							.replaceAll("<model_name>", ExcelUtils.getCellData("Sheet1", i, 0)).replaceAll("[-]", " ")
							.replaceAll("[^a-zA-Z0-9 ]", "");
				if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<part_name>")
						&& ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<part_name>", ExcelUtils.getCellData("Sheet1", i, 4))
							.replaceAll("<model_name>", ExcelUtils.getCellData("Sheet1", i, 0)).replaceAll("[-]", " ")
							.replaceAll("[^a-zA-Z0-9 ]", "");
				System.out.println("input_text-->" + input_text);
				String expected_partnames = ExcelUtils.getCellData("Sheet1", i, 4).trim().toLowerCase();
				String expected_partnumbers = ExcelUtils.getCellData("Sheet1", i, 3).trim().toLowerCase();
				String expected_model_name = ExcelUtils.getCellData("Sheet1", i, 0).trim().toLowerCase();
				String expected_assembly_name = ExcelUtils.getCellData("Sheet1", i, 2).trim().toLowerCase();
				String expected_alternate_model_name = ExcelUtils.getCellData("Sheet1", i, 1).trim().toLowerCase();
				String expected_image_status = ExcelUtils.getCellData("Sheet1", i, 5).trim().toLowerCase();
				System.out.println("expected_partnumbers-->" + expected_partnumbers);
				System.out.println("expected_partnames-->" + expected_partnames);
				System.out.println("expected_model_name-->" + expected_model_name);
				System.out.println("expected_assembly_name-->" + expected_assembly_name);
				System.out.println("expected_alternate_model_name-->" + expected_alternate_model_name);
				System.out.println("expected_image_status-->" + expected_image_status);
				ExcelUtils.setCellData("Sheet1", input_text, i, ul);
				if (ProductAPICalls.getPartsDetailsWhenSeachedwithModelName(env, expected_model_name,
						expected_assembly_name, expected_partnumbers, expected_partnames, expected_image_status,
						input_text, expected_alternate_model_name)) {
					System.out.println("--->" + "Entering for Loop");
					for (int i1 = ul + 1; i1 <= ul + 5; i1++)
						ExcelUtils.setCellData("Sheet1", "PASS", i, i1, HSSFColor.GREEN.index);
				} else {
					for (int i1 = ul + 1; i1 <= ul + 5; i1++)
						ExcelUtils.setCellData("Sheet1", "FAIL", i, i1, HSSFColor.RED.index);
				}
			}
		}
		ExcelUtils.closeExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup_Model_Name.xlsx");
		return this;
	}

	public PartsAPIMission verifyPartsDetailsByParentName(String env) throws Throwable {
		ExcelUtils.setExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup_Only_Model_Name.xlsx");
		for (int ul = 4; ul < ExcelUtils.getLastColumnNo("Sheet1", 0); ul = ul + 4) {
			int rowno = 1;
			for (int i = 1; i <= ExcelUtils.getLastRownNo("Sheet1"); i = rowno) {
				String model_Name = ExcelUtils.getCellData("Sheet1", i, 0);
				String alternate_model_Name = ExcelUtils.getCellData("Sheet1", i, 1);
				String input_text = "";
				if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<partial_model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<partial_model_name>",
									getPartialModelName(ExcelUtils.getCellData("Sheet1", i, 0)))
							.replaceAll("[-]", " ").replaceAll("[^a-zA-Z0-9 ]", "");
				else if (ExcelUtils.getCellData("Sheet1", 0, ul).toLowerCase().contains("<model_name>"))
					input_text = input_text + ExcelUtils.getCellData("Sheet1", 0, ul)
							.replaceAll("<model_name>", ExcelUtils.getCellData("Sheet1", i, 0)).replaceAll("[-]", " ")
							.replaceAll("[^a-zA-Z0-9 ]", "");
				System.out.println("input_text-->" + input_text);
				List<String> expected_partnames = new ArrayList<String>();
				List<String> expected_partnumbers = new ArrayList<String>();
				Map<String, String> expected_model_name = new LinkedHashMap<String, String>();
				Map<String, String> expected_alternate_model_name = new LinkedHashMap<String, String>();
				int jLoopSize = getStepSize(i);
				for (int j = i; j <= jLoopSize; j++) {
					expected_partnumbers.add(ExcelUtils.getCellData("Sheet1", j, 2).trim().toLowerCase());
					expected_alternate_model_name.put(ExcelUtils.getCellData("Sheet1", j, 2).trim().toLowerCase(),
							ExcelUtils.getCellData("Sheet1", i, 1).trim().toLowerCase());
					expected_model_name.put(ExcelUtils.getCellData("Sheet1", j, 2).trim().toLowerCase(),
							ExcelUtils.getCellData("Sheet1", i, 0).trim().toLowerCase());
					expected_partnames.add(ExcelUtils.getCellData("Sheet1", j, 3).trim().toLowerCase());
				}
				System.out.println("expected_partnumbers-->" + expected_partnumbers);
				System.out.println("expected_partnames-->" + expected_partnames);
				System.out.println("expected_model_name-->" + expected_model_name);
				System.out.println("expected_alternate_model_name-->" + expected_alternate_model_name);
				ProductAPICalls.getPartNamesByParentName(env, model_Name, alternate_model_Name, input_text);
				System.out.println("actualPartsDetails-->" + ProductAPICalls.actualPartsDetails);
				System.out.println("actual_model_name-->" + ProductAPICalls.actual_model_name);
				if (ProductAPICalls.actualPartsDetails.size() != 0) {
					for (int j = 0; j < expected_partnames.size(); j++) {
						ExcelUtils.setCellData("Sheet1", input_text, rowno, ul);
						try {
							if (ProductAPICalls.actual_model_name.get(expected_partnumbers.get(j))
									.contains(expected_model_name.get(expected_partnumbers.get(j)))
									|| ProductAPICalls.actual_model_name.get(expected_partnumbers.get(j))
											.contains(expected_alternate_model_name.get(expected_partnumbers.get(j))))
								ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 1, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 1, HSSFColor.RED.index);
							if (ProductAPICalls.actualPartsDetails.contains(expected_partnames.get(j)))
								ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 2, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 2, HSSFColor.RED.index);
							if (ProductAPICalls.actualPartsDetails.contains(expected_partnumbers.get(j)))
								ExcelUtils.setCellData("Sheet1", "PASS", rowno, ul + 3, HSSFColor.GREEN.index);
							else
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, ul + 3, HSSFColor.RED.index);
						} catch (Exception e) {
							for (int k = ul + 1; k <= ul + 3; k++) {
								ExcelUtils.setCellData("Sheet1", "FAIL", rowno, k, HSSFColor.RED.index);
							}
						}
						rowno++;
					}
				} else {
					for (int j = 0; j < expected_partnames.size(); j++) {
						ExcelUtils.setCellData("Sheet1", input_text, rowno, ul);
						ExcelUtils.setCellData("Sheet1", "Parts Data Not Displayed", rowno, ul + 1,
								HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "Parts Data Not Displayed", rowno, ul + 2,
								HSSFColor.RED.index);
						ExcelUtils.setCellData("Sheet1", "Parts Data Not Displayed", rowno, ul + 3,
								HSSFColor.RED.index);
						rowno++;
					}
				}
			}
		}
		ExcelUtils.closeExcelFile(
				System.getProperty("user.dir") + "/src/test/resources/testdata/Parts_Lookup_Only_Model_Name.xlsx");
		return this;
	}
}
